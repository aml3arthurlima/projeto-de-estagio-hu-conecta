"""
Aparência do HU Conecta: fontes, cores e imagem de fundo.

"""

import base64
import os

import streamlit as st

PASTA_ASSETS = os.path.join(os.path.dirname(__file__), "assets")
CAMINHO_LOGO = os.path.join(PASTA_ASSETS, "logo.png")
CAMINHO_FUNDO = os.path.join(PASTA_ASSETS, "fundo.png")
CAMINHO_PARCEIROS = os.path.join(PASTA_ASSETS, "parceiros.png")

def _imagem_para_base64(caminho: str) -> str | None:
    """Lê um arquivo de imagem e devolve como data URI (texto), ou None se não existir."""
    if not os.path.exists(caminho):
        return None
    extensao = caminho.split(".")[-1]
    with open(caminho, "rb") as f:
        conteudo = base64.b64encode(f.read()).decode("utf-8")
    return f"data:image/{extensao};base64,{conteudo}"


def aplicar_logo():
    """
    Coloca uma imagem no topo da página (acima do menu), no lugar
    reservado pelo Streamlit para logos. Se você não tiver colocado um
    arquivo em assets/logo.png ainda, simplesmente não faz nada --
    assim o app não quebra por falta do arquivo.
    """
    if os.path.exists(CAMINHO_LOGO):
        st.logo(CAMINHO_LOGO, size="large")
    # Se não existir logo.png, seguimos só com o emoji do favicon
    # (definido em st.set_page_config, no app_streamlit.py).


def aplicar_estilo():
    """
    Injeta o CSS que define: fonte da página, cor/tamanho dos números
    de compatibilidade, e (se existir) a imagem de fundo.

    Para trocar a fonte: mude o nome depois de "family=" na URL do
    Google Fonts, e troque 'Poppins' nas regras abaixo pelo mesmo nome.
    Veja outras fontes em https://fonts.google.com/

    Para adicionar uma imagem de fundo: salve um arquivo .jpg em
    assets/fundo.jpg (crie a pasta "assets" ao lado do app_streamlit.py
    se ela não existir). O CSS abaixo já procura esse arquivo sozinho.
    """
    fundo_base64 = _imagem_para_base64(CAMINHO_FUNDO)

    regra_fundo = ""
    if fundo_base64:
        regra_fundo = f"""
        .stApp {{
            background-image: url("{fundo_base64}");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }}

        /* Cartão branco central com o conteúdo do app (formulário,
           textos, etc.) -- sem isso o conteúdo fica "solto" direto
           em cima da imagem de fundo. */
        .block-container {{
            background-color: #ffffff;
            border-radius: 16px;
            padding: 2.5rem 3rem;
            max-width: 900px;
            margin: 3rem auto;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.35);
        }}

        /* Força texto escuro dentro do cartão, independente do tema
           (claro/escuro) que o Streamlit esteja usando -- é isso que
           resolve o texto "sumindo" por ter a mesma cor do fundo. */
        .block-container, .block-container p, .block-container label,
        .block-container span, .block-container li {{
            color: #1a1a1a !important;
        }}

        /* Campos de e-mail/senha: fundo branco e borda visível, para
           não ficarem transparentes/azuis em cima do fundo. */
        .block-container input {{
            background-color: #ffffff !important;
            color: #1a1a1a !important;
            border: 1px solid #ccc !important;
        }}

        /* Caixas de aviso (st.info) dentro do cartão: texto escuro
           também, já que por padrão herdam a cor do tema. */
        .block-container [data-testid="stAlert"] p {{
            color: #1a1a1a !important;
        }}
        """

    st.markdown(
        
        f"""
        <style>
        /* 1. Importa a fonte "Poppins" do Google Fonts */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');

        /* 2. Aplica essa fonte em praticamente todo o texto da página */
        html, body, [class*="css"] {{
            font-family: 'Poppins', sans-serif;
        }}
                /* Aumenta o tamanho da letra de tudo dentro do cartão */
        .block-container {{
            font-size: 1.30rem;
        }}

        /* Rótulos dos campos (E-mail, Senha) */
        .block-container label p {{
            font-size: 1.1rem !important;
        }}

        /* Texto digitado dentro dos campos de input */
        .block-container input {{
            font-size: 1.1rem !important;
            padding: 0.6rem 0.8rem !important;
        }}

        /* Texto dos botões (Entrar, Preencher cadastro...) */
        .block-container button p {{
            font-size: 1.05rem !important;
        }}

        /* Abas "Entrar" / "Já me cadastrei..." */
        .block-container [data-testid="stTab"] p {{
            font-size: 1.05rem !important;
        }}

        /* Texto de descrição/aviso (parágrafos soltos, st.info) */
        .block-container [data-testid="stAlert"] p {{
            font-size: 1.05rem !important;
        }}

        /* 3. Título principal (st.title) um pouco maior e com peso 700 */
        h1 {{
            font-weight: 700;
            color: #1E3A8A;
        }}
                /* Força tamanho de fonte em TUDO dentro da área principal do app,
           não só dentro de .block-container -- cobre mudanças de versão
           do Streamlit que renomeiam essa classe */
        [data-testid="stMain"] p,
        [data-testid="stMain"] label,
        [data-testid="stMain"] span,
        [data-testid="stMain"] div {{
            font-size: 1.3rem !important;
        }}

        [data-testid="stMain"] input {{
            font-size: 1.3rem !important;
            padding: 0.7rem 0.9rem !important;
        }}

        [data-testid="stMain"] button p {{
            font-size: 1.2rem !important;
        }}
         
        [data-testid="InputInstructions"] {{
            display: none;
        }}

        /* 4. Estiliza o número grande de "Compatibilidade" (st.metric).
              O seletor abaixo mira no atributo interno que o Streamlit
              usa para esse elemento -- pode mudar em versões futuras
              do Streamlit, então se parar de funcionar um dia, é por
              isso (esse é o "preço" de customizar além do que a
              biblioteca oferece oficialmente). */
        div[data-testid="stMetricValue"] {{
            font-size: 2.6rem;
            font-weight: 700;
            color: #2563EB;
        }}

        {regra_fundo}
        </style>
        """,
        unsafe_allow_html=True,
    )


def aplicar_faixa_protótipo(texto: str = "Protótipo -- HU Conecta"):
    """
    Mostra uma faixa fixa no canto inferior esquerdo da tela, sempre
    visível mesmo quando a página é rolada. Útil para marcar "isso é um
    protótipo/versão de teste" durante uma demonstração.

    A POSIÇÃO no CSS é definida por estas quatro propriedades juntas:

    - position: fixed;   -> tira o elemento do fluxo normal da página e
                             o "gruda" na JANELA do navegador, não na
                             página (por isso ele não rola junto com o
                             conteúdo).
    - bottom: 0;          -> cola na borda de BAIXO da tela.
    - left: 0;            -> cola na borda da ESQUERDA da tela.
                             (para canto inferior DIREITO, troque
                             "left: 0" por "right: 0"; para canto
                             SUPERIOR esquerdo, troque "bottom: 0" por
                             "top: 0")
    - z-index: 9999;      -> garante que a faixa fique por CIMA dos
                             outros elementos da página, não escondida
                             atrás deles.
    """
    st.markdown(
        f"""
        <div style="
            position: fixed;
            bottom: 0;
            left: 0;
            z-index: 9999;
            background-color: #1E3A8A;
            color: white;
            padding: 6px 16px;
            font-size: 0.8rem;
            border-top-right-radius: 8px;
            opacity: 0.9;
        ">
            {texto}
        </div>
        """,
        unsafe_allow_html=True,
    )

def aplicar_rodape_logos(largura_px: int = 400):
    """
    Mostra, ao final do conteúdo da página, a imagem com os logos dos
    parceiros (assets/parceiros.png).
    """
    imagem_b64 = _imagem_para_base64(CAMINHO_PARCEIROS)
    if not imagem_b64:
        return

    st.markdown(
        f"""
        <div style="
            display: flex;
            justify-content: center;
            padding: 1.5rem 0 0.5rem 0;
            margin-top: 1.5rem;
            border-top: 1px solid #e5e7eb;
        ">
            <img src="{imagem_b64}" style="width: {largura_px}px; max-width: 100%;" />
        </div>
        """,
        unsafe_allow_html=True,
    )
