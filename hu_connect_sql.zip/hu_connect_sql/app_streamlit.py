"""
HU Conecta (versão SQL) -- frontend em Streamlit.

Rodar com:
    python database.py            # cria as tabelas (só na primeira vez)
    streamlit run app_streamlit.py

Tudo acontece dentro do sistema: a pessoa cria a conta na aba "Criar conta"
(confirmando o e-mail por código), edita o perfil na própria tela e, se esquecer
a senha, usa "Esqueci minha senha". Os dados ficam no banco SQL definido em
DATABASE_URL (SQLite por padrão). Para o envio de e-mails funcionar, configure o
SMTP no .env, ou use EMAIL_MODO=console para ver os e-mails no terminal.

Opcional, para ter gente para testar: python popular_exemplo.py
"""

import os

import streamlit as st
from sqlalchemy import or_

import email_service
from auth import (
    TAMANHO_MINIMO_SENHA, criar_hash_senha, normalizar_email,
    precisa_atualizar_hash, senha_confere,
)
from cadastro import (
    atualizar_perfil, confirmar_cadastro, dados_do_formulario, excluir_conta,
    iniciar_cadastro, reenviar_codigo_cadastro,
)
from aparencia import aplicar_logo, aplicar_estilo, aplicar_faixa_protótipo, aplicar_rodape_logos
from componentes import (
    mostrar_compatibilidade, mostrar_meu_resumo, mostrar_perfil_completo,
    mostrar_resumo_interesses,
)
from database import SessionLocal, init_db
from formulario import formulario_perfil
from models import Pessoa, Interacao, Match, Credencial
from notificacoes import ids_que_demonstraram_interesse, registrar_interacao
from recuperacao import redefinir_senha, solicitar_codigo
from rotulos import resumo_interesses

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

st.set_page_config(page_title="HU Conecta", page_icon="🔗", layout="centered")
init_db()  # cria as tabelas novas (códigos de recuperação, avisos) se ainda não existirem
aplicar_logo()
aplicar_estilo()


db = SessionLocal()
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    caminho_logo = os.path.join(BASE_DIR, "assets", "logo.png")
    if os.path.exists(caminho_logo):
        st.image(caminho_logo, width=400)

st.caption("Protótipo -- Conecte. Colabore. Inove.\n"
           "Encontre discentes, docentes e servidores com interesses em comum para criar projetos de pesquisa e inovação no HUAC. Faça conexões, forme equipes e transforme ideias em impacto para a saúde.")

# ---------- Login / Recuperação de senha ----------

if "pessoa_id" not in st.session_state:
    st.session_state.pessoa_id = None

if "cad_etapa" not in st.session_state:
    st.session_state.cad_etapa = 1   # 1 = preencher o formulário, 2 = digitar o código

if st.session_state.pessoa_id is None:
    aba_entrar, aba_cadastro, aba_recuperar = st.tabs(["Entrar", "Criar conta", "Esqueci minha senha"])

    with aba_entrar:
        with st.form("login_form"):
            email = st.text_input("E-mail")
            senha = st.text_input("Senha", type="password")
            entrar = st.form_submit_button("Entrar")

        if entrar:
            email_normalizado = normalizar_email(email)
            credencial = db.query(Credencial).filter(Credencial.email == email_normalizado).first()
            if credencial and senha_confere(senha, credencial.senha_hash, credencial.salt):
                # Hash no formato antigo? Aproveita que a senha acabou de ser confirmada e atualiza.
                if precisa_atualizar_hash(credencial.senha_hash):
                    credencial.senha_hash = criar_hash_senha(senha)
                    credencial.salt = ""
                    db.commit()
                st.session_state.pessoa_id = credencial.pessoa_id
                st.rerun()
            else:
                st.error("E-mail ou senha incorretos.")

    with aba_cadastro:
        if st.session_state.cad_etapa == 1:
            st.write("Crie sua conta para encontrar pessoas com interesses em comum no HUAC. "
                     "Campos com * são obrigatórios.")
            if not email_service.email_configurado():
                st.warning("O envio de e-mails ainda não está configurado neste ambiente, "
                           "então não será possível confirmar o cadastro. Procure a equipe do sistema.")
            enviado, dados_cad, senha_cad, conf_cad = formulario_perfil(
                "cadastro", valores=st.session_state.get("cad_dados"), com_senha=True,
                botao="Criar conta e enviar código")
            if enviado:
                with st.spinner("Verificando e enviando o código..."):
                    ok, mensagens = iniciar_cadastro(db, dados_cad, senha_cad, conf_cad)
                if ok:
                    st.session_state.cad_email = normalizar_email(dados_cad["email"])
                    st.session_state.cad_dados = dados_cad   # para "Voltar e corrigir" não perder o que foi digitado
                    st.session_state.cad_etapa = 2
                    st.rerun()
                else:
                    for mensagem in mensagens:
                        st.error(mensagem)
        else:
            st.success(f"Enviamos um código de 6 dígitos para **{st.session_state.get('cad_email', '')}**. "
                       "Confira também a caixa de spam. Ele vale por 15 minutos.")
            with st.form("cadastro_codigo_form"):
                codigo_cad = st.text_input("Código de 6 dígitos", max_chars=6)
                confirmar = st.form_submit_button("Confirmar cadastro", type="primary")
            if confirmar:
                ok, mensagem, novo_id = confirmar_cadastro(db, st.session_state.get("cad_email", ""), codigo_cad)
                if ok:
                    st.session_state.pessoa_id = novo_id
                    st.session_state.cad_etapa = 1
                    st.session_state.pop("cad_dados", None)
                    st.rerun()
                else:
                    st.error(mensagem)
            c_a, c_b = st.columns(2)
            if c_a.button("Reenviar código", use_container_width=True):
                ok, mensagem = reenviar_codigo_cadastro(db, st.session_state.get("cad_email", ""))
                (st.success if ok else st.warning)(mensagem)
            if c_b.button("Voltar e corrigir meus dados", use_container_width=True):
                st.session_state.cad_etapa = 1
                st.rerun()

    with aba_recuperar:
        st.write(
            "Esqueceu a senha? Informe o e-mail institucional do seu "
            "cadastro e enviaremos um **código de 6 dígitos** para ele. Com o código, você "
            "escolhe uma senha nova."
        )
        if not email_service.email_configurado():
            st.warning(
                "O envio de e-mails ainda não está configurado neste ambiente. "
                "Procure a equipe responsável pelo sistema."
            )

        with st.form("recuperar_solicitar_form"):
            email_rec = st.text_input("E-mail institucional")
            pedir_codigo = st.form_submit_button("Enviar código")

        if pedir_codigo:
            with st.spinner("Enviando..."):
                solicitar_codigo(db, email_rec)
            st.session_state.rec_email = normalizar_email(email_rec)
            st.session_state.rec_codigo_enviado = True
            # Mesma resposta exista o e-mail ou não -- ninguém descobre quem está cadastrado.
            st.success(
                "Se esse e-mail estiver cadastrado, enviamos um código para ele. "
                "Confira também a caixa de spam. O código vale por 15 minutos."
            )

        if not st.session_state.get("rec_codigo_enviado"):
            if st.button("Já tenho um código"):
                st.session_state.rec_codigo_enviado = True
                st.rerun()
        else:
            st.divider()
            st.markdown("**Agora digite o código e escolha a nova senha**")
            with st.form("recuperar_confirmar_form"):
                email_conf = st.text_input("E-mail institucional", value=st.session_state.get("rec_email", ""))
                codigo = st.text_input("Código de 6 dígitos", max_chars=6)
                nova_senha = st.text_input(
                    "Nova senha", type="password",
                    help=f"Use pelo menos {TAMANHO_MINIMO_SENHA} caracteres.",
                )
                confirmar_senha = st.text_input("Confirme a nova senha", type="password")
                redefinir = st.form_submit_button("Redefinir senha")

            if redefinir:
                ok, mensagem = redefinir_senha(db, email_conf, codigo, nova_senha, confirmar_senha)
                if ok:
                    st.session_state.rec_codigo_enviado = False
                    st.success(mensagem)
                else:
                    st.error(mensagem)

    aplicar_rodape_logos()

    db.close()
    st.stop()

# ---------- Usuário logado ----------

pessoa_id = st.session_state.pessoa_id
eu = db.get(Pessoa, pessoa_id)

col_a, col_b = st.columns([4, 1])
col_a.write(f"Logado como **{eu.nome}** ({eu.curso or eu.vinculo})")
if col_b.button("Sair"):
    st.session_state.pessoa_id = None
    st.rerun()

# Aviso: pessoas que já curtiram você e esperam sua resposta.
interessados = ids_que_demonstraram_interesse(db, pessoa_id)
if interessados:
    n = len(interessados)
    if n == 1:
        st.info("💙 **1 pessoa** demonstrou interesse em se conectar com você. "
                "Ela aparece primeiro nas suas recomendações.")
    else:
        st.info(f"💙 **{n} pessoas** demonstraram interesse em se conectar com você. "
                "Elas aparecem primeiro nas suas recomendações.")

st.divider()

ja_vistas_ids = {
    i.destino_id for i in
    db.query(Interacao).filter(Interacao.origem_id == pessoa_id).all()
}

matches = (
    db.query(Match)
    .filter(or_(Match.pessoa_1_id == pessoa_id, Match.pessoa_2_id == pessoa_id))
    .order_by(Match.score_total.desc())
    .all()
)

candidatos = []
for m in matches:
    outro_id = m.pessoa_2_id if m.pessoa_1_id == pessoa_id else m.pessoa_1_id
    if outro_id not in ja_vistas_ids:
        candidatos.append((m, outro_id))

# Quem já demonstrou interesse em você vem primeiro (a ordem por compatibilidade se mantém dentro de cada grupo).
candidatos.sort(key=lambda c: c[1] not in interessados)

if not candidatos:
    st.info("Sem novas recomendações no momento. Volte depois que mais pessoas se cadastrarem!")
else:
    match, outro_id = candidatos[0]
    outro = db.get(Pessoa, outro_id)

    with st.container(border=True):
        if outro_id in interessados:
            st.success("💙 Esta pessoa já demonstrou interesse em se conectar com você!")

        st.subheader(outro.nome)
        st.write(f"**{outro.vinculo}** • {outro.curso or '—'} • {outro.instituicao or '—'}")
        if outro.bio:
            st.write(outro.bio)
        if outro.lattes:
            st.markdown(f"[Currículo Lattes]({outro.lattes})")

        mostrar_compatibilidade(match)

        st.write("")
        mostrar_resumo_interesses(eu, outro)
        mostrar_perfil_completo(outro)

        st.write("")
        c1, c2 = st.columns(2)

        if c1.button("Ignorar", use_container_width=True,
                     help="Passa para a próxima pessoa. Você pode reconsiderar depois, na lista de ignorados."):
            registrar_interacao(db, pessoa_id, outro_id, "skip")
            st.rerun()

        if c2.button("Quero alinhar pesquisa", use_container_width=True, type="primary",
                     help="Demonstra interesse. Avisamos a pessoa por e-mail; se ela também quiser, "
                          "vocês trocam contato."):
            with st.spinner("Registrando seu interesse..."):
                resultado = registrar_interacao(db, pessoa_id, outro_id, "like")

            if resultado.conexao:
                st.success(f"Vocês se conectaram com {outro.nome}! Veja os dados de contato abaixo.")
                st.markdown(f"**E-mail:** {outro.email or 'não informado'}")
                st.markdown(f"**Telefone:** {outro.telefone or 'não informado'}")
                if resultado.emails_enviados:
                    st.caption("📧 Também avisamos vocês dois por e-mail.")
            else:
                st.rerun()

st.divider()

st.subheader("Suas conexões")
likes_dados = {
    i.destino_id for i in
    db.query(Interacao).filter(Interacao.origem_id == pessoa_id, Interacao.tipo == "like").all()
}
likes_recebidos = {
    i.origem_id for i in
    db.query(Interacao).filter(Interacao.destino_id == pessoa_id, Interacao.tipo == "like").all()
}
ids_match = likes_dados & likes_recebidos

if not ids_match:
    st.caption("Nenhuma conexão confirmada ainda.")
else:
    for outro_id in ids_match:
        outro = db.get(Pessoa, outro_id)
        if outro:
            with st.container(border=True):
                st.write(f"**{outro.nome}** — {outro.curso or outro.vinculo}")
                st.caption(f"E-mail: {outro.email or 'não informado'}  |  Telefone: {outro.telefone or 'não informado'}")
                em_comum = resumo_interesses(eu, outro)["em_comum"]
                if em_comum:
                    resto = f" (+{len(em_comum) - 5})" if len(em_comum) > 5 else ""
                    st.caption("Interesses em comum: " + ", ".join(em_comum[:5]) + resto)

st.divider()

# ---------- Meu resumo de interesses ----------

mostrar_meu_resumo(eu)

with st.expander("Editar meu perfil"):
    enviado_ed, dados_ed, _, _ = formulario_perfil(
        "editar_perfil", valores=dados_do_formulario(eu), editando=True, botao="Salvar alterações")
    if enviado_ed:
        ok, mensagens = atualizar_perfil(db, pessoa_id, dados_ed)
        if ok:
            st.success("Perfil atualizado! Suas compatibilidades foram recalculadas.")
        else:
            for mensagem in mensagens:
                st.error(mensagem)

with st.expander("Excluir minha conta"):
    st.warning("Isso apaga seu perfil, suas conexões e seus dados do HU Conecta. Não dá para desfazer.")
    with st.form("excluir_conta_form"):
        senha_exclusao = st.text_input("Digite sua senha para confirmar", type="password")
        excluir = st.form_submit_button("Excluir minha conta definitivamente")
    if excluir:
        ok, mensagem = excluir_conta(db, pessoa_id, senha_exclusao)
        if ok:
            st.session_state.pessoa_id = None
            st.rerun()
        else:
            st.error(mensagem)

st.divider()

# ---------- Pessoas ignoradas (para reconsiderar, se quiser) ----------

interacoes_da_pessoa = (
    db.query(Interacao)
    .filter(Interacao.origem_id == pessoa_id)
    .order_by(Interacao.id.asc())
    .all()
)

# guarda sempre a interação MAIS RECENTE por destino (a última na ordem)
status_por_destino = {}
for i in interacoes_da_pessoa:
    status_por_destino[i.destino_id] = i.tipo

ids_ignorados = [destino_id for destino_id, tipo in status_por_destino.items() if tipo == "skip"]

if "ignorados_aberto" not in st.session_state:
    st.session_state.ignorados_aberto = False

with st.expander(f"Pessoas que você ignorou ({len(ids_ignorados)})", expanded=st.session_state.ignorados_aberto):
    if not ids_ignorados:
        st.caption("Você ainda não ignorou ninguém.")
    else:
        # ordena pelas mais compatíveis primeiro, usando o score já calculado
        ignorados_com_score = []
        for outro_id in ids_ignorados:
            m = (
                db.query(Match)
                .filter(
                    or_(
                        (Match.pessoa_1_id == pessoa_id) & (Match.pessoa_2_id == outro_id),
                        (Match.pessoa_1_id == outro_id) & (Match.pessoa_2_id == pessoa_id),
                    )
                )
                .first()
            )
            ignorados_com_score.append((m.score_total if m else 0, outro_id))
        ignorados_com_score.sort(reverse=True)

        for score, outro_id in ignorados_com_score:
            outro = db.get(Pessoa, outro_id)
            if outro is None:
                continue
            with st.container(border=True):
                col_info, col_acao = st.columns([3, 2])
                col_info.write(f"**{outro.nome}** — {outro.curso or outro.vinculo}")
                col_info.caption(f"Compatibilidade: {score:.0f}%")

                if col_acao.button("Reconsiderar", key=f"reconsiderar_{outro_id}", use_container_width=True,
                                   help="Volta atrás e demonstra interesse nesta pessoa."):
                    st.session_state.ignorados_aberto = True
                    with st.spinner("Registrando seu interesse..."):
                        resultado = registrar_interacao(db, pessoa_id, outro_id, "like")

                    if resultado.conexao:
                        st.success(f"Vocês se conectaram com {outro.nome}!")
                        st.markdown(f"**E-mail:** {outro.email or 'não informado'}")
                        st.markdown(f"**Telefone:** {outro.telefone or 'não informado'}")
                        if resultado.emails_enviados:
                            st.caption("📧 Também avisamos vocês dois por e-mail.")
                    else:
                        st.info(f"Você demonstrou interesse em {outro.nome} novamente.")
                        st.rerun()
aplicar_rodape_logos()
db.close()
