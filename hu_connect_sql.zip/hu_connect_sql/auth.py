"""
Funções de autenticação do HU Connect.

SENHAS
------
A senha NUNCA é guardada em texto puro. Ela vira um hash PBKDF2-HMAC-SHA256
(biblioteca padrão do Python, nada extra para instalar) com um "salt"
aleatório único por pessoa e 600.000 iterações (recomendação atual da OWASP).

O hash é guardado em UMA string só, já com tudo que é preciso para conferir
a senha depois:

    pbkdf2_sha256$600000$<salt>$<hash>

Esse formato é o usado no banco (tabela Credencial).

Hashes antigos (100.000 iterações, com o salt numa coluna separada) continuam
funcionando: quando a pessoa entra com sucesso, o hash é atualizado sozinho
para o formato novo (veja `precisa_atualizar_hash`).

CÓDIGO DE RECUPERAÇÃO DE SENHA
------------------------------
Quem esqueceu a senha recebe por e-mail um código de 6 dígitos, válido por
poucos minutos e com limite de tentativas. O código também é guardado só em
forma de hash (HMAC-SHA256 com salt) -- nunca em texto puro.
"""

import hashlib
import hmac
import secrets
from datetime import datetime, timedelta

DURACAO_TOKEN = timedelta(days=7)

# Só e-mails desses domínios podem criar senha e acessar o sistema.
# Ajuste essa lista para os domínios reais das instituições envolvidas.
DOMINIOS_PERMITIDOS = [
    "uepb.edu.br",
    "ufcg.edu.br",
    "huac.ebserh.gov.br",
    "ebserh.gov.br",  # cobre outros e-mails @ebserh.gov.br além do @huac
    "ifpb.edu.br",
]

# ---------- Parâmetros do hash de senha ----------
ALGORITMO = "pbkdf2_sha256"
ITERACOES = 600_000          # valor atual (hashes novos)
ITERACOES_LEGADO = 100_000   # valor do formato antigo (salt em coluna separada)
TAMANHO_MINIMO_SENHA = 8

# ---------- Parâmetros da recuperação de senha ----------
VALIDADE_CODIGO = timedelta(minutes=15)
MAX_TENTATIVAS_CODIGO = 5
INTERVALO_MINIMO_REENVIO = timedelta(seconds=60)


# ---------- E-mail e domínio ----------

def normalizar_email(email: str) -> str:
    """E-mails são comparados sem espaços e em minúsculo, para evitar
    erros bobos de 'pessoa não encontrada' por diferença de caixa."""
    return (email or "").strip().lower()


def dominio_permitido(email: str) -> bool:
    """
    Confere se o domínio do e-mail é um dos institucionais aceitos,
    incluindo subdomínios. Ex: 'joao@aluno.uepb.edu.br' é aceito porque
    o domínio termina em 'uepb.edu.br'.
    """
    email = normalizar_email(email)
    if "@" not in email:
        return False
    dominio = email.split("@", 1)[1]
    return any(dominio == d or dominio.endswith("." + d) for d in DOMINIOS_PERMITIDOS)


# ---------- Hash de senha ----------

def gerar_salt() -> str:
    """Gera um valor aleatório único, usado para 'temperar' o hash."""
    return secrets.token_hex(16)


def _pbkdf2_hex(senha: str, salt: str, iteracoes: int) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256",
        senha.encode("utf-8"),
        salt.encode("utf-8"),
        iteracoes,
    ).hex()


def criar_hash_senha(senha: str) -> str:
    """
    Transforma a senha em um hash pronto para guardar, no formato
    'pbkdf2_sha256$<iterações>$<salt>$<hash>'. Cada chamada gera um salt
    novo, então a mesma senha nunca produz o mesmo texto duas vezes.
    """
    salt = gerar_salt()
    return f"{ALGORITMO}${ITERACOES}${salt}${_pbkdf2_hex(senha, salt, ITERACOES)}"


def eh_hash_formatado(valor) -> bool:
    """True se o texto já está no formato 'pbkdf2_sha256$it$salt$hash'."""
    if not isinstance(valor, str):
        return False
    partes = valor.split("$")
    return (
        len(partes) == 4
        and partes[0] == ALGORITMO
        and partes[1].isdigit()
        and bool(partes[2])
        and bool(partes[3])
    )


def senha_confere(senha: str, hash_armazenado: str, salt_legado: str = "") -> bool:
    """
    Confere se a senha digitada corresponde ao hash guardado.

    - Formato novo: tudo (iterações, salt, hash) vem dentro de `hash_armazenado`.
    - Formato antigo: `hash_armazenado` é só o hash e `salt_legado` traz o salt
      da coluna separada (100.000 iterações).

    A comparação é feita em tempo constante (hmac.compare_digest) para não
    vazar informação pelo tempo de resposta.
    """
    if not senha or not hash_armazenado:
        return False

    try:
        if eh_hash_formatado(hash_armazenado):
            _, iteracoes, salt, esperado = hash_armazenado.split("$")
            calculado = _pbkdf2_hex(senha, salt, int(iteracoes))
        else:
            if not salt_legado:
                return False
            esperado = hash_armazenado
            calculado = _pbkdf2_hex(senha, salt_legado, ITERACOES_LEGADO)
    except (ValueError, OverflowError):
        return False

    return hmac.compare_digest(calculado, esperado)


def precisa_atualizar_hash(hash_armazenado: str) -> bool:
    """True se o hash está no formato antigo ou com menos iterações que o
    padrão atual -- nesse caso vale regravar assim que a senha for confirmada."""
    if not eh_hash_formatado(hash_armazenado):
        return True
    return int(hash_armazenado.split("$")[1]) < ITERACOES


def validar_nova_senha(senha: str, confirmacao: str | None = None) -> str | None:
    """Devolve uma mensagem de erro (texto) se a senha não serve, ou None se está ok."""
    if confirmacao is not None and senha != confirmacao:
        return "As senhas não coincidem."
    if len(senha or "") < TAMANHO_MINIMO_SENHA:
        return f"Escolha uma senha com pelo menos {TAMANHO_MINIMO_SENHA} caracteres."
    return None


# ---------- Código de recuperação de senha ----------

def gerar_codigo_recuperacao() -> str:
    """Código numérico de 6 dígitos, gerado com fonte aleatória segura."""
    return f"{secrets.randbelow(1_000_000):06d}"


def hash_codigo(codigo: str, salt: str) -> str:
    """HMAC-SHA256 do código, usando o salt como chave."""
    return hmac.new(salt.encode("utf-8"), codigo.strip().encode("utf-8"), hashlib.sha256).hexdigest()


def codigo_confere(codigo: str, salt: str, hash_esperado: str) -> bool:
    return hmac.compare_digest(hash_codigo(codigo, salt), hash_esperado)


# ---------- Token de sessão (usado pela API) ----------

def gerar_token() -> str:
    """Gera um token de sessão aleatório e imprevisível."""
    return secrets.token_urlsafe(32)


def token_expirado(criado_em: datetime) -> bool:
    return datetime.utcnow() > criado_em + DURACAO_TOKEN
