"""
Cadastro, edição de perfil e exclusão de conta (tudo direto no banco SQL).

CADASTRO EM DOIS PASSOS
-----------------------
1. `iniciar_cadastro` valida o formulário, guarda tudo como "cadastro pendente"
   (com a senha já em hash) e manda um código de 6 dígitos para o e-mail.
2. `confirmar_cadastro` confere o código; só então a pessoa passa a existir
   (tabelas Pessoa e Credencial) e seus pares de compatibilidade são calculados.

Assim ninguém cria conta com o e-mail de outra pessoa. O código vale 15 min, tem
no máximo 5 tentativas e novo pedido só depois de 60 s (mesmos limites da
recuperação de senha, definidos em auth.py).
"""

import json
from datetime import datetime

from sqlalchemy.exc import IntegrityError

import email_service
from auth import (
    INTERVALO_MINIMO_REENVIO, MAX_TENTATIVAS_CODIGO, VALIDADE_CODIGO,
    codigo_confere, criar_hash_senha, gerar_codigo_recuperacao, gerar_salt, hash_codigo,
    normalizar_email, senha_confere, validar_nova_senha,
)
from gerar_matches import recalcular_matches_da_pessoa
from models import (
    CadastroPendente, CodigoRecuperacao, Credencial, Interacao, Match, Notificacao,
    Pessoa, Sessao,
)
from perfil import para_campos_pessoa, validar_dados

MSG_CODIGO_INVALIDO = "Código inválido ou expirado. Confira o código ou peça um novo."


def _aplicar_dados(pessoa: Pessoa, dados: dict) -> None:
    for campo, valor in para_campos_pessoa(dados).items():
        setattr(pessoa, campo, valor)
    pessoa.dados_form = json.dumps(dados, ensure_ascii=False)


def criar_pessoa(db, dados: dict, senha_hash: str) -> Pessoa:
    """Cria Pessoa + Credencial, sem validação nem confirmação de e-mail
    (quem chama já validou). Também é usada pelo script de dados de exemplo."""
    pessoa = Pessoa()
    _aplicar_dados(pessoa, dados)
    db.add(pessoa)
    db.flush()  # gera o id
    db.add(Credencial(pessoa_id=pessoa.id, email=pessoa.email, senha_hash=senha_hash, salt=""))
    db.commit()
    recalcular_matches_da_pessoa(db, pessoa.id)
    return pessoa


def _enviar_codigo_cadastro(pendente: CadastroPendente, nome: str, codigo: str) -> bool:
    assunto, texto, html = email_service.montar_email_confirmacao_cadastro(
        nome, codigo, int(VALIDADE_CODIGO.total_seconds() // 60)
    )
    return email_service.enviar_email(pendente.email, assunto, texto, html)


def _novo_codigo(pendente: CadastroPendente) -> str:
    codigo = gerar_codigo_recuperacao()
    pendente.salt = gerar_salt()
    pendente.codigo_hash = hash_codigo(codigo, pendente.salt)
    pendente.criado_em = datetime.utcnow()
    pendente.expira_em = pendente.criado_em + VALIDADE_CODIGO
    pendente.tentativas = 0
    return codigo


def iniciar_cadastro(db, dados: dict, senha: str, confirmacao: str) -> tuple:
    """Devolve (ok, [mensagens]). Se ok, o código foi enviado para o e-mail."""
    dados = {**dados, "email": normalizar_email(dados.get("email", ""))}

    erros = validar_dados(dados)
    erro_senha = validar_nova_senha(senha, confirmacao)
    if erro_senha:
        erros.append(erro_senha)
    if erros:
        return False, erros

    email = dados["email"]
    if db.query(Pessoa).filter(Pessoa.email == email).first():
        return False, ["Este e-mail já tem cadastro. Se esqueceu a senha, use a aba \"Esqueci minha senha\"."]

    pendente = db.query(CadastroPendente).filter(CadastroPendente.email == email).first()
    if pendente and datetime.utcnow() - pendente.criado_em < INTERVALO_MINIMO_REENVIO:
        return False, ["Aguarde um minuto antes de pedir um novo código."]

    if pendente is None:
        pendente = CadastroPendente(email=email)
        db.add(pendente)
    pendente.dados_json = json.dumps(dados, ensure_ascii=False)
    pendente.senha_hash = criar_hash_senha(senha)
    codigo = _novo_codigo(pendente)
    db.commit()

    if not _enviar_codigo_cadastro(pendente, dados["nome"].strip(), codigo):
        db.delete(pendente)
        db.commit()
        return False, ["Não foi possível enviar o e-mail de confirmação agora. "
                       "Tente novamente em alguns minutos ou procure a equipe do sistema."]
    return True, []


def reenviar_codigo_cadastro(db, email: str) -> tuple:
    """Gera e envia um código novo para um cadastro pendente. Devolve (ok, mensagem)."""
    email = normalizar_email(email)
    pendente = db.query(CadastroPendente).filter(CadastroPendente.email == email).first()
    if pendente is None:
        return False, "Não há cadastro aguardando confirmação para esse e-mail. Preencha o formulário de novo."
    if datetime.utcnow() - pendente.criado_em < INTERVALO_MINIMO_REENVIO:
        return False, "Aguarde um minuto antes de pedir um novo código."
    codigo = _novo_codigo(pendente)
    db.commit()
    nome = json.loads(pendente.dados_json).get("nome", "").strip()
    if not _enviar_codigo_cadastro(pendente, nome, codigo):
        return False, "Não foi possível enviar o e-mail agora. Tente novamente em alguns minutos."
    return True, "Enviamos um novo código."


def confirmar_cadastro(db, email: str, codigo: str) -> tuple:
    """Devolve (ok, mensagem, pessoa_id ou None)."""
    email = normalizar_email(email)
    pendente = db.query(CadastroPendente).filter(CadastroPendente.email == email).first()

    if (
        pendente is None
        or datetime.utcnow() > pendente.expira_em
        or (pendente.tentativas or 0) >= MAX_TENTATIVAS_CODIGO
    ):
        return False, MSG_CODIGO_INVALIDO, None

    if not codigo_confere(codigo or "", pendente.salt, pendente.codigo_hash):
        pendente.tentativas = (pendente.tentativas or 0) + 1
        db.commit()
        return False, MSG_CODIGO_INVALIDO, None

    dados = json.loads(pendente.dados_json)
    senha_hash = pendente.senha_hash
    db.delete(pendente)
    db.commit()

    try:
        pessoa = criar_pessoa(db, dados, senha_hash)
    except IntegrityError:  # alguém confirmou o mesmo e-mail ao mesmo tempo
        db.rollback()
        return False, "Este e-mail já tem cadastro. Use a aba \"Entrar\".", None
    return True, "Cadastro concluído! Bem-vindo(a) ao HU Conecta.", pessoa.id


def atualizar_perfil(db, pessoa_id: int, dados: dict) -> tuple:
    """Salva a edição do perfil. O e-mail não muda aqui. Devolve (ok, [mensagens])."""
    pessoa = db.get(Pessoa, pessoa_id)
    if pessoa is None:
        return False, ["Pessoa não encontrada."]

    dados = {**dados, "email": pessoa.email}  # o e-mail é a identidade da conta
    erros = validar_dados(dados, validar_dominio_do_email=False)
    if erros:
        return False, erros

    _aplicar_dados(pessoa, dados)
    db.commit()
    recalcular_matches_da_pessoa(db, pessoa.id)
    return True, []


def dados_do_formulario(pessoa: Pessoa) -> dict:
    """Respostas salvas no cadastro, para preencher de novo o formulário na edição."""
    try:
        return json.loads(pessoa.dados_form) if pessoa.dados_form else {}
    except ValueError:
        return {}


def excluir_conta(db, pessoa_id: int, senha: str) -> tuple:
    """
    Apaga a pessoa e tudo que se refere a ela (perfil, senha, sessões, pares de
    compatibilidade, curtidas/ignoradas dadas e recebidas, códigos e avisos).
    Pede a senha como confirmação. Devolve (ok, mensagem).
    """
    credencial = db.query(Credencial).filter(Credencial.pessoa_id == pessoa_id).first()
    if credencial is None or not senha_confere(senha or "", credencial.senha_hash, credencial.salt):
        return False, "Senha incorreta."

    db.query(Match).filter((Match.pessoa_1_id == pessoa_id) | (Match.pessoa_2_id == pessoa_id)).delete(
        synchronize_session=False)
    db.query(Interacao).filter((Interacao.origem_id == pessoa_id) | (Interacao.destino_id == pessoa_id)).delete(
        synchronize_session=False)
    db.query(Notificacao).filter(
        (Notificacao.destinatario_id == pessoa_id) | (Notificacao.outro_id == pessoa_id)).delete(
        synchronize_session=False)
    db.query(CodigoRecuperacao).filter(CodigoRecuperacao.pessoa_id == pessoa_id).delete(synchronize_session=False)
    db.query(Sessao).filter(Sessao.pessoa_id == pessoa_id).delete(synchronize_session=False)
    db.query(Credencial).filter(Credencial.pessoa_id == pessoa_id).delete(synchronize_session=False)
    db.query(Pessoa).filter(Pessoa.id == pessoa_id).delete(synchronize_session=False)
    db.commit()
    return True, "Sua conta foi excluída."
