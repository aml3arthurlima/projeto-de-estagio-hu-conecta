"""
Peças de tela reutilizáveis do HU Conecta (caixinhas de interrogação,
resumo de interesses, perfil completo).

Ficam aqui, separadas do app_streamlit.py, para o arquivo principal continuar
curto e para os textos de ajuda ficarem todos em um lugar só
(rotulos.textos_de_ajuda).
"""

from html import escape

import streamlit as st

from matching import PESOS
from rotulos import resumo_do_perfil, resumo_interesses, textos_de_ajuda

AJUDA = textos_de_ajuda(PESOS)

# (chave em AJUDA, texto exibido, atributo do Match que guarda a nota)
CRITERIOS = [
    ("interesses", "Interesses", "score_interesses"),
    ("atividade", "Atividade", "score_atividade"),
    ("papel", "Papel", "score_papel"),
    ("competencias", "Competências", "score_competencias"),
    ("disponibilidade", "Disponibilidade", "score_disponibilidade"),
]

LIMITE_CHIPS = 8


def _chips(itens: list, destaque: bool = False, limite: int | None = None) -> str:
    """Etiquetas arredondadas (HTML). Todo texto é escapado."""
    fundo, texto = ("#DBEAFE", "#1E3A8A") if destaque else ("#EEF0F4", "#333333")
    mostrados = itens if limite is None else itens[:limite]
    html = "".join(
        f'<span style="display:inline-block;margin:2px 6px 2px 0;padding:2px 10px;'
        f'border-radius:999px;background:{fundo};color:{texto};font-size:0.85rem">'
        f"{escape(item)}</span>"
        for item in mostrados
    )
    extra = len(itens) - len(mostrados)
    if extra > 0:
        html += f'<span style="font-size:0.85rem;color:#666">+{extra}</span>'
    return html


def mostrar_compatibilidade(match) -> None:
    """Nota total + as 5 notas por critério, cada uma com sua caixinha de '?'."""
    st.metric("Compatibilidade", f"{match.score_total:.0f}%", help=AJUDA["compatibilidade"])

    colunas = st.columns(len(CRITERIOS))
    for coluna, (chave, titulo, atributo) in zip(colunas, CRITERIOS):
        with coluna:
            st.markdown(f"**{titulo}**\n\n{getattr(match, atributo):.0f}%", help=AJUDA[chave])

    with st.popover("❓ O que significam esses critérios?"):
        st.markdown("**Compatibilidade** — " + AJUDA["compatibilidade"])
        for chave, titulo, _ in CRITERIOS:
            st.markdown(f"**{titulo}** — {AJUDA[chave]}")


def mostrar_resumo_interesses(eu, outro) -> None:
    """Resumo dos interesses da outra pessoa em comparação com os meus."""
    r = resumo_interesses(eu, outro)
    st.markdown("**Resumo de interesses**", help=AJUDA["resumo_interesses"])

    if r["total_b"] == 0:
        st.caption("Essa pessoa não marcou áreas de interesse no cadastro.")
        return

    st.caption(
        f"Vocês têm {len(r['em_comum'])} interesse(s) em comum, de {r['total_uniao']} "
        f"no total entre os dois ({r['percentual_comum']}%)."
    )
    if r["em_comum"]:
        st.markdown("✅ **Em comum**", unsafe_allow_html=False)
        st.markdown(_chips(r["em_comum"], destaque=True), unsafe_allow_html=True)
    else:
        st.caption("Nenhuma área de interesse em comum — outros critérios ainda podem combinar.")

    if r["so_b"]:
        st.markdown("➕ **Também se interessa por**")
        st.markdown(_chips(r["so_b"], limite=LIMITE_CHIPS), unsafe_allow_html=True)


def mostrar_perfil_completo(pessoa, titulo: str = "Ver perfil completo") -> None:
    """Todos os critérios da pessoa em texto legível, dentro de um expansor."""
    with st.expander(titulo):
        for nome, itens in resumo_do_perfil(pessoa).items():
            st.markdown(f"**{nome}**")
            if itens:
                st.markdown(_chips(itens), unsafe_allow_html=True)
            else:
                st.caption("Não informado.")


def mostrar_meu_resumo(eu) -> None:
    """Resumo do meu próprio perfil (quantos interesses, quais, e o resto dos critérios)."""
    perfil = resumo_do_perfil(eu)
    qtd = len(perfil["Interesses"])
    with st.expander(f"Meu resumo de interesses ({qtd})"):
        if qtd:
            st.markdown(_chips(perfil["Interesses"], destaque=True), unsafe_allow_html=True)
        else:
            st.caption("Você ainda não marcou áreas de interesse. Use \"Editar meu perfil\" abaixo.")
        for nome in ("Objetivo", "Papel", "Competências", "Disponibilidade"):
            if perfil[nome]:
                st.markdown(f"**{nome}**")
                st.markdown(_chips(perfil[nome]), unsafe_allow_html=True)
