"""
Configuração e criação do banco de dados auxiliar (SQLite por padrão).

Rode este arquivo diretamente uma vez para criar as tabelas:
    python database.py
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv
from models import Base

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./huconnect.db")

# check_same_thread=False é necessário só para SQLite (não afeta Postgres)
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def init_db():
    Base.metadata.create_all(engine)


if __name__ == "__main__":
    init_db()
    print(f"Banco de dados criado com sucesso em: {DATABASE_URL}")
