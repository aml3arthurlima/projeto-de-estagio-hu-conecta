"""
Define (ou redefine) a senha de uma pessoa, a partir do e-mail cadastrado.

Ferramenta de ADMINISTRAÇÃO, pela linha de comando. Para o dia a dia, quem
esqueceu a senha usa a aba "Esqueci minha senha" da tela de login (código
por e-mail). Use este script quando precisar definir uma senha na mão, por
exemplo para testes ou se o e-mail ainda não estiver configurado.

A senha é guardada só como hash (veja auth.py).

Uso:
    python definir_senha.py email@exemplo.com
    (o script vai pedir a senha de forma interativa, sem mostrar na tela)
"""

import sys
import getpass

from database import SessionLocal, init_db
from models import Pessoa, Credencial
from auth import criar_hash_senha, dominio_permitido, normalizar_email, validar_nova_senha


def definir_senha(email: str, senha: str):
    email = normalizar_email(email)

    if not dominio_permitido(email):
        print(f"O e-mail '{email}' não pertence a um domínio institucional aceito "
              f"(veja DOMINIOS_PERMITIDOS em auth.py). Senha não criada.")
        return False

    db = SessionLocal()
    try:
        pessoa = db.query(Pessoa).filter(Pessoa.email == email).first()
        if pessoa is None:
            print(f"Nenhuma pessoa encontrada com o e-mail '{email}' no banco de dados. "
                  f"Confirme se a pessoa já concluiu o cadastro.")
            return False

        credencial = db.query(Credencial).filter(Credencial.pessoa_id == pessoa.id).first()
        senha_hash = criar_hash_senha(senha)

        if credencial is None:
            credencial = Credencial(pessoa_id=pessoa.id, email=email, senha_hash=senha_hash, salt="")
            db.add(credencial)
        else:
            credencial.senha_hash = senha_hash
            credencial.salt = ""

        db.commit()
        print(f"Senha definida com sucesso para {pessoa.nome} ({email}).")

        return True
    finally:
        db.close()


if __name__ == "__main__":
    init_db()

    if len(sys.argv) < 2:
        print("Uso: python definir_senha.py email@exemplo.com")
        sys.exit(1)

    email_informado = sys.argv[1]
    senha_informada = getpass.getpass("Digite a nova senha: ")
    confirmacao = getpass.getpass("Confirme a nova senha: ")

    if senha_informada != confirmacao:
        print("As senhas não coincidem. Tente novamente.")
        sys.exit(1)

    erro = validar_nova_senha(senha_informada)
    if erro:
        print(erro)
        sys.exit(1)

    definir_senha(email_informado, senha_informada)
