"""
Envio de e-mails do HU Connect (confirmação de cadastro, recuperação de senha e avisos).

Usa só a biblioteca padrão (smtplib). A configuração vem do .env:

    SMTP_HOST=smtp.exemplo.gov.br
    SMTP_PORT=587
    SMTP_USER=usuario
    SMTP_PASSWORD=senha
    SMTP_USE_STARTTLS=true     # porta 587 (padrão). Para porta 465 use SMTP_USE_SSL=true
    SMTP_USE_SSL=false
    EMAIL_REMETENTE=huconecta@seudominio.gov.br   # se vazio, usa SMTP_USER
    EMAIL_NOME_REMETENTE=HU Conecta
    APP_URL=https://endereco-do-sistema          # link que vai nos e-mails

MODO DE TESTE: com EMAIL_MODO=console nada é enviado; o e-mail inteiro é
impresso no terminal onde o Streamlit está rodando. Útil para desenvolver
sem servidor de e-mail (o código de recuperação aparece lá).

Todo texto vindo de cadastro (nome, bio...) é escapado antes de entrar no
HTML do e-mail, e quebras de linha são removidas do assunto.
"""

import logging
import os
import smtplib
import ssl
from email.message import EmailMessage
from email.utils import formataddr
from html import escape

from dotenv import load_dotenv

load_dotenv()
log = logging.getLogger("hu_connect.email")


def _bool(valor: str, padrao: bool) -> bool:
    if valor is None or valor.strip() == "":
        return padrao
    return valor.strip().lower() in ("1", "true", "sim", "yes", "on")


def _config() -> dict:
    usuario = os.getenv("SMTP_USER", "").strip()
    try:
        porta = int(os.getenv("SMTP_PORT", "587"))
    except ValueError:
        porta = 587
    return {
        "modo": os.getenv("EMAIL_MODO", "smtp").strip().lower(),
        "host": os.getenv("SMTP_HOST", "").strip(),
        "porta": porta,
        "usuario": usuario,
        "senha": os.getenv("SMTP_PASSWORD", ""),
        "ssl": _bool(os.getenv("SMTP_USE_SSL"), False),
        "starttls": _bool(os.getenv("SMTP_USE_STARTTLS"), True),
        "remetente": (os.getenv("EMAIL_REMETENTE", "").strip() or usuario),
        "nome": os.getenv("EMAIL_NOME_REMETENTE", "HU Conecta").strip() or "HU Conecta",
    }


def app_url() -> str:
    return os.getenv("APP_URL", "").strip()


def email_configurado() -> bool:
    """True se dá para enviar (SMTP configurado) ou se está em modo console."""
    cfg = _config()
    return cfg["modo"] == "console" or bool(cfg["host"] and cfg["remetente"])


def enviar_email(destino: str, assunto: str, texto: str, html: str | None = None) -> bool:
    """
    Envia um e-mail. Devolve True se foi enviado (ou impresso, no modo
    console) e False se falhou -- nunca levanta exceção, para que um
    problema de e-mail não derrube a tela do usuário.
    """
    destino = (destino or "").strip()
    if not destino or "@" not in destino:
        return False

    cfg = _config()
    assunto = " ".join((assunto or "").split())  # remove quebras de linha (header injection)

    if cfg["modo"] == "console":
        print("\n" + "=" * 60)
        print(f"[E-MAIL SIMULADO] Para: {destino}\nAssunto: {assunto}\n\n{texto}")
        print("=" * 60 + "\n", flush=True)
        return True

    if not (cfg["host"] and cfg["remetente"]):
        log.warning("E-mail não enviado: SMTP_HOST/EMAIL_REMETENTE não configurados no .env.")
        print("Aviso: e-mail não enviado -- configure SMTP_HOST e EMAIL_REMETENTE no .env "
              "(ou use EMAIL_MODO=console para testar).")
        return False

    try:
        msg = EmailMessage()
        msg["Subject"] = assunto
        msg["From"] = formataddr((cfg["nome"], cfg["remetente"]))
        msg["To"] = destino
        msg.set_content(texto)
        if html:
            msg.add_alternative(html, subtype="html")

        contexto = ssl.create_default_context()
        if cfg["ssl"]:
            servidor = smtplib.SMTP_SSL(cfg["host"], cfg["porta"], timeout=10, context=contexto)
        else:
            servidor = smtplib.SMTP(cfg["host"], cfg["porta"], timeout=10)
        with servidor:
            if not cfg["ssl"] and cfg["starttls"]:
                servidor.starttls(context=contexto)
            if cfg["usuario"]:
                servidor.login(cfg["usuario"], cfg["senha"])
            servidor.send_message(msg)
        return True
    except (smtplib.SMTPException, OSError, ValueError) as erro:
        # Não registramos a senha nem o conteúdo; só o tipo do problema.
        log.error("Falha ao enviar e-mail para %s: %s", destino, erro)
        print(f"Aviso: falha ao enviar e-mail para {destino}: {erro}")
        return False


# ---------- Montagem dos e-mails ----------

def _html_base(titulo: str, blocos: list, rodape: str = "") -> str:
    corpo = "".join(blocos)
    link = app_url()
    botao = (
        f'<p style="margin:24px 0"><a href="{escape(link, quote=True)}" '
        'style="background:#2563EB;color:#fff;padding:10px 20px;border-radius:6px;'
        'text-decoration:none;font-weight:600">Abrir o HU Conecta</a></p>'
        if link else ""
    )
    return (
        '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:auto;'
        'color:#1A1A1A;line-height:1.5">'
        f'<h2 style="color:#0B4F85;margin-bottom:8px">{escape(titulo)}</h2>'
        f"{corpo}{botao}"
        f'<hr style="border:none;border-top:1px solid #ddd;margin:24px 0">'
        f'<p style="font-size:12px;color:#666">{escape(rodape or "HU Conecta — Hospital Universitário Alcides Carneiro")}</p>'
        "</div>"
    )


def _p(texto: str) -> str:
    return f'<p style="margin:8px 0">{escape(texto)}</p>'


def _lista_html(itens: list) -> str:
    if not itens:
        return ""
    return "<ul style=\"margin:6px 0 12px 18px;padding:0\">" + "".join(
        f"<li>{escape(i)}</li>" for i in itens
    ) + "</ul>"


def _bloco_interesses(em_comum: list) -> tuple:
    """(texto, html) com o resumo dos interesses em comum."""
    if not em_comum:
        return "", ""
    mostrados = em_comum[:8]
    extra = len(em_comum) - len(mostrados)
    texto = "Interesses em comum:\n" + "\n".join(f"  - {i}" for i in mostrados)
    if extra > 0:
        texto += f"\n  (+{extra})"
    html = (
        '<p style="margin:12px 0 0"><strong>Interesses em comum</strong></p>'
        + _lista_html(mostrados + ([f"+{extra} outros"] if extra > 0 else []))
    )
    return texto + "\n", html


def _descricao_pessoa(p: dict) -> str:
    partes = [p.get("vinculo"), p.get("curso"), p.get("instituicao")]
    return " • ".join(x for x in partes if x)


def montar_email_codigo(nome: str, codigo: str, validade_min: int) -> tuple:
    assunto = "HU Conecta — código para redefinir sua senha"
    texto = (
        f"Olá, {nome}!\n\n"
        f"Seu código para redefinir a senha do HU Conecta é: {codigo}\n\n"
        f"Ele vale por {validade_min} minutos e só pode ser usado uma vez.\n"
        "Se você não pediu isso, ignore este e-mail — sua senha continua a mesma.\n"
    )
    html = _html_base("Redefinição de senha", [
        _p(f"Olá, {nome}!"),
        _p("Use este código para redefinir a senha do HU Conecta:"),
        f'<p style="font-size:32px;letter-spacing:8px;font-weight:700;margin:16px 0">{escape(codigo)}</p>',
        _p(f"Ele vale por {validade_min} minutos e só pode ser usado uma vez."),
        _p("Se você não pediu isso, ignore este e-mail — sua senha continua a mesma."),
    ])
    return assunto, texto, html


def montar_email_confirmacao_cadastro(nome: str, codigo: str, validade_min: int) -> tuple:
    assunto = "HU Conecta — confirme seu e-mail para concluir o cadastro"
    texto = (
        f"Olá, {nome}!\n\n"
        f"Seu código para concluir o cadastro no HU Conecta é: {codigo}\n\n"
        f"Ele vale por {validade_min} minutos. Digite-o na tela de cadastro.\n"
        "Se você não fez esse cadastro, ignore este e-mail — nenhuma conta será criada.\n"
    )
    html = _html_base("Confirme seu cadastro", [
        _p(f"Olá, {nome}!"),
        _p("Use este código para concluir seu cadastro no HU Conecta:"),
        f'<p style="font-size:32px;letter-spacing:8px;font-weight:700;margin:16px 0">{escape(codigo)}</p>',
        _p(f"Ele vale por {validade_min} minutos."),
        _p("Se você não fez esse cadastro, ignore este e-mail — nenhuma conta será criada."),
    ])
    return assunto, texto, html


def montar_email_senha_alterada(nome: str) -> tuple:
    assunto = "HU Conecta — sua senha foi alterada"
    texto = (
        f"Olá, {nome}!\n\n"
        "A senha da sua conta no HU Conecta acabou de ser alterada.\n"
        "Se foi você, não precisa fazer nada. Se NÃO foi você, peça uma nova "
        "redefinição de senha imediatamente e avise a equipe do sistema.\n"
    )
    html = _html_base("Senha alterada", [
        _p(f"Olá, {nome}!"),
        _p("A senha da sua conta no HU Conecta acabou de ser alterada."),
        _p("Se foi você, não precisa fazer nada. Se NÃO foi você, peça uma nova "
           "redefinição de senha imediatamente e avise a equipe do sistema."),
    ])
    return assunto, texto, html


def montar_email_novo_interesse(nome_destinatario: str, quem: dict, em_comum: list,
                                revelar_nome: bool) -> tuple:
    """
    quem: dict com nome, vinculo, curso, instituicao da pessoa que demonstrou
    interesse. Se revelar_nome=False, o e-mail descreve só o perfil.
    O contato (e-mail/telefone) NUNCA vai neste aviso -- só quando há conexão mútua.
    """
    descricao = _descricao_pessoa(quem)
    if revelar_nome and quem.get("nome"):
        assunto = f"HU Conecta — {quem['nome']} quer se conectar com você"
        linha = f"{quem['nome']} demonstrou interesse em se conectar com você."
    else:
        assunto = "HU Conecta — alguém quer se conectar com você"
        linha = "Uma pessoa demonstrou interesse em se conectar com você."

    txt_int, html_int = _bloco_interesses(em_comum)
    texto = (
        f"Olá, {nome_destinatario}!\n\n{linha}\n"
        + (f"Perfil: {descricao}\n" if descricao else "")
        + (f"\n{txt_int}" if txt_int else "")
        + "\nEntre no HU Conecta para ver o perfil completo. Se você também tiver interesse, "
          "é só clicar em \"Quero alinhar pesquisa\" — os contatos de vocês dois são liberados "
          "quando o interesse for mútuo.\n"
        + (f"\nAcesse: {app_url()}\n" if app_url() else "")
    )
    blocos = [_p(f"Olá, {nome_destinatario}!"), _p(linha)]
    if descricao:
        blocos.append(_p(f"Perfil: {descricao}"))
    if html_int:
        blocos.append(html_int)
    blocos.append(_p("Se você também tiver interesse, é só clicar em \"Quero alinhar pesquisa\". "
                     "Os contatos de vocês dois são liberados quando o interesse for mútuo."))
    return assunto, texto, _html_base("Novo interesse em você", blocos)


def montar_email_conexao(nome_destinatario: str, outro: dict, em_comum: list) -> tuple:
    """Aviso de conexão confirmada (interesse mútuo), já com o contato da outra pessoa."""
    assunto = f"HU Conecta — você e {outro.get('nome') or 'uma pessoa'} se conectaram!"
    descricao = _descricao_pessoa(outro)
    email_outro = outro.get("email") or "não informado"
    tel_outro = outro.get("telefone") or "não informado"

    txt_int, html_int = _bloco_interesses(em_comum)
    texto = (
        f"Olá, {nome_destinatario}!\n\n"
        f"Boa notícia: o interesse foi mútuo! Você e {outro.get('nome', '')} se conectaram.\n"
        + (f"Perfil: {descricao}\n" if descricao else "")
        + f"\nContato:\n  E-mail: {email_outro}\n  Telefone: {tel_outro}\n"
        + (f"\n{txt_int}" if txt_int else "")
        + "\nAgora é só entrar em contato para alinhar o projeto."
        + (f"\n\nAcesse: {app_url()}\n" if app_url() else "\n")
    )
    blocos = [
        _p(f"Olá, {nome_destinatario}!"),
        _p(f"Boa notícia: o interesse foi mútuo! Você e {outro.get('nome', '')} se conectaram."),
    ]
    if descricao:
        blocos.append(_p(f"Perfil: {descricao}"))
    blocos.append(
        '<p style="margin:12px 0 0"><strong>Contato</strong></p>'
        f'<p style="margin:4px 0">E-mail: {escape(email_outro)}<br>Telefone: {escape(tel_outro)}</p>'
    )
    if html_int:
        blocos.append(html_int)
    blocos.append(_p("Agora é só entrar em contato para alinhar o projeto."))
    return assunto, texto, _html_base("Vocês se conectaram!", blocos)
