"""
Formulário de perfil (usado no cadastro e na edição), em Streamlit.

`formulario_perfil` desenha o formulário e devolve o que foi digitado; quem
chama (app_streamlit.py) decide o que fazer: validar, salvar etc. As regras de
validação ficam em perfil.py, não aqui.
"""

import streamlit as st

from componentes import AJUDA
from perfil import SUBAREAS_POR_AREA, dados_vazios
from rotulos import opcoes


def _multi(rotulo_campo: str, campo: str, chave: str, atual: list, ajuda: str | None = None) -> list:
    textos = opcoes(campo)
    return st.multiselect(
        rotulo_campo, list(textos),
        default=[c for c in atual if c in textos],
        format_func=lambda c: textos[c],
        key=chave, help=ajuda, placeholder="Escolha uma ou mais opções",
    )


def _unico(rotulo_campo: str, campo: str, chave: str, atual: str, obrigatorio: bool) -> str:
    textos = opcoes(campo)
    codigos = list(textos)
    escolhido = st.selectbox(
        rotulo_campo + (" *" if obrigatorio else ""), codigos,
        index=codigos.index(atual) if atual in codigos else None,
        format_func=lambda c: textos[c],
        key=chave, placeholder="Selecione",
    )
    return escolhido or ""


def formulario_perfil(chave: str, valores: dict | None = None, com_senha: bool = False,
                      editando: bool = False, botao: str = "Salvar") -> tuple:
    """
    Desenha o formulário e devolve (enviado, dados, senha, confirmacao).
    `valores` preenche os campos (edição). Campos com * são obrigatórios.
    """
    v = {**dados_vazios(), **(valores or {})}
    interesses_atuais = set(v["interesses"])

    with st.form(chave):
        st.markdown("##### Seus dados")
        nome = st.text_input("Nome completo *", value=v["nome"], key=f"{chave}_nome")
        email = st.text_input(
            "E-mail institucional *", value=v["email"], key=f"{chave}_email",
            disabled=editando,
            help="Use o e-mail da sua instituição (UEPB, UFCG, IFPB, EBSERH/HUAC). "
                 + ("O e-mail não pode ser alterado." if editando else "Enviaremos um código de confirmação para ele."),
        )
        telefone = st.text_input("Telefone com DDD *", value=v["telefone"], key=f"{chave}_tel",
                                 placeholder="(83) 99999-9999")
        lattes = st.text_input("Link do Currículo Lattes *", value=v["lattes"], key=f"{chave}_lattes",
                               placeholder="http://lattes.cnpq.br/...")

        st.markdown("##### Vínculo")
        vinculo = _unico("Vínculo", "vinculo", f"{chave}_vinculo", v["vinculo"], True)
        curso = _unico("Curso (se for o caso)", "curso", f"{chave}_curso", v["curso"], False)
        instituicoes = _multi("Instituição de vínculo *", "instituicao_de_vinculo", f"{chave}_inst", v["instituicoes"])
        outras = st.text_input("Se marcou \"Outra\", qual?", value=v["outras_instituicoes"], key=f"{chave}_outras")
        bio = st.text_area("Bio (conte um pouco sobre você)", value=v["bio"], key=f"{chave}_bio", max_chars=1000)

        st.markdown("##### O que você procura")
        papel = _multi("Papel *", "papel", f"{chave}_papel", v["papel"], AJUDA["papel"])
        objetivo = _multi("Objetivo", "objetivo", f"{chave}_obj", v["objetivo"], AJUDA["atividade"])
        competencias = _multi("Competências", "competencias", f"{chave}_comp", v["competencias"], AJUDA["competencias"])

        st.markdown("##### Interesses")
        st.caption(AJUDA["interesses"])
        areas = _multi(
            "Grandes áreas de interesse *", "interesses", f"{chave}_areas",
            [k.split(":", 1)[1] for k in interesses_atuais if k.startswith("interesses:")],
        )
        interesses = [f"interesses:{c}" for c in areas]
        titulos = opcoes("interesses")
        for codigo_area, campo_sub in SUBAREAS_POR_AREA.items():
            with st.expander(f"Subáreas — {titulos.get(codigo_area, campo_sub)}"):
                subs = _multi(
                    "Subáreas", campo_sub, f"{chave}_{campo_sub}",
                    [k.split(":", 1)[1] for k in interesses_atuais if k.startswith(f"{campo_sub}:")],
                )
                interesses += [f"{campo_sub}:{c}" for c in subs]

        st.markdown("##### Disponibilidade")
        disp_dias = _multi("Dias da semana *", "disp_dias", f"{chave}_dias", v["disp_dias"], AJUDA["disponibilidade"])
        disp_periodo = _multi("Períodos *", "disp_periodo", f"{chave}_periodo", v["disp_periodo"])

        senha = confirmacao = ""
        if com_senha:
            st.markdown("##### Senha de acesso")
            senha = st.text_input("Senha *", type="password", key=f"{chave}_senha",
                                  help="Mínimo de 8 caracteres.")
            confirmacao = st.text_input("Confirme a senha *", type="password", key=f"{chave}_senha2")

        enviado = st.form_submit_button(botao, type="primary", use_container_width=True)

    dados = {
        "nome": nome, "email": email, "telefone": telefone, "lattes": lattes,
        "vinculo": vinculo, "curso": curso, "instituicoes": instituicoes,
        "outras_instituicoes": outras, "bio": bio, "objetivo": objetivo,
        "papel": papel, "competencias": competencias, "interesses": interesses,
        "disp_dias": disp_dias, "disp_periodo": disp_periodo,
    }
    return enviado, dados, senha, confirmacao
