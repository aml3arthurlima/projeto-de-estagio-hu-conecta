"""
Calcula a compatibilidade entre TODOS os pares de pessoas cadastradas
e salva o resultado na tabela `matches`.

No dia a dia você NÃO precisa rodar este arquivo: sempre que alguém se
cadastra ou edita o perfil, `recalcular_matches_da_pessoa` atualiza só os pares
dessa pessoa. Rodar `python gerar_matches.py` recalcula tudo do zero (útil se
você mudar os pesos em matching.py).
"""

from itertools import combinations

from sqlalchemy import or_

from database import SessionLocal, init_db
from models import Pessoa, Match
from matching import calcular_compatibilidade


def gerar_matches():
    db = SessionLocal()
    try:
        pessoas = db.query(Pessoa).all()

        if len(pessoas) < 2:
            print("É preciso ao menos 2 pessoas cadastradas para gerar matches.")
            return 0

        db.query(Match).delete()

        total = 0
        for a, b in combinations(pessoas, 2):
            resultado = calcular_compatibilidade(a, b)
            match = Match(
                pessoa_1_id=a.id,
                pessoa_2_id=b.id,
                score_total=resultado.score_total,
                score_interesses=resultado.score_interesses,
                score_atividade=resultado.score_atividade,
                score_papel=resultado.score_papel,
                score_competencias=resultado.score_competencias,
                score_disponibilidade=resultado.score_disponibilidade,
            )
            db.add(match)
            total += 1

        db.commit()
        print(f"{total} pares de compatibilidade calculados entre {len(pessoas)} pessoas.")
        return total
    finally:
        db.close()


def recalcular_matches_da_pessoa(db, pessoa_id: int) -> int:
    """
    Apaga e recalcula só os pares que envolvem `pessoa_id` (novo cadastro ou
    perfil editado). Usa a sessão recebida e faz commit. Devolve quantos pares.
    """
    db.query(Match).filter(
        or_(Match.pessoa_1_id == pessoa_id, Match.pessoa_2_id == pessoa_id)
    ).delete(synchronize_session=False)

    pessoa = db.get(Pessoa, pessoa_id)
    if pessoa is None:
        db.commit()
        return 0

    total = 0
    for outro in db.query(Pessoa).filter(Pessoa.id != pessoa_id).all():
        a, b = (pessoa, outro) if pessoa.id < outro.id else (outro, pessoa)
        r = calcular_compatibilidade(a, b)
        db.add(Match(
            pessoa_1_id=a.id, pessoa_2_id=b.id,
            score_total=r.score_total, score_interesses=r.score_interesses,
            score_atividade=r.score_atividade, score_papel=r.score_papel,
            score_competencias=r.score_competencias, score_disponibilidade=r.score_disponibilidade,
        ))
        total += 1
    db.commit()
    return total


if __name__ == "__main__":
    init_db()
    gerar_matches()
