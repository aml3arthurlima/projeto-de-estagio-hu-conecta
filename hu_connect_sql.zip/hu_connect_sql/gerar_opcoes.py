"""
(Opcional) Regera dados/opcoes.json a partir de um CSV de dicionário de dados.

O arquivo dados/opcoes.json já vem pronto e é ele que o sistema usa para montar
o formulário de cadastro e os textos das opções (áreas de interesse,
competências, objetivos, vínculo, curso...). Só rode isto se quiser trocar a
lista de opções:

    python gerar_opcoes.py caminho/do/dicionario.csv

O CSV precisa ter as colunas 'Variable / Field Name', 'Field Type' e
'Choices, Calculations, OR Slider Labels' (formato de dicionário de dados do
REDCap). Mas atenção: o arquivo final pode ser editado à mão -- é só um JSON
{campo: {código: texto}}.
"""
import json
import sys

from rotulos import CAMINHO_OPCOES, carregar_de_csv

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    opcoes = carregar_de_csv(sys.argv[1])
    with open(CAMINHO_OPCOES, "w", encoding="utf-8") as f:
        json.dump(opcoes, f, ensure_ascii=False, indent=1)
    print(f"{len(opcoes)} campos gravados em {CAMINHO_OPCOES}")
