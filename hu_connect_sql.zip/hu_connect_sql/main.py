"""
API REST do HU Connect, agora com login (e-mail + senha).

Rodar com:
    uvicorn main:app --reload

Documentação interativa automática em:
    http://127.0.0.1:8000/docs

Como funciona a autenticação:
1. A pessoa faz POST em /auth/login com email + senha.
2. Se corretos, a API cria um "token" de sessão (uma string aleatória)
   e devolve esse token para o cliente.
3. Nas próximas chamadas, o cliente envia esse token no cabeçalho:
       Authorization: Bearer <token>
4. A API confere se o token existe e não expirou, e assim sabe quem
   é a pessoa autenticada -- sem precisar confiar em nenhum dado que
   o cliente mande sobre "quem eu sou".
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from sqlalchemy import or_
from pydantic import BaseModel

from database import SessionLocal, init_db
from models import Pessoa, Match, Interacao, Credencial, Sessao
from auth import (
    criar_hash_senha, gerar_token, normalizar_email, precisa_atualizar_hash,
    senha_confere, token_expirado,
)
from notificacoes import registrar_interacao as registrar_interacao_com_aviso
from recuperacao import redefinir_senha, solicitar_codigo


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()  # garante que as tabelas existem antes de a API começar a atender
    yield


app = FastAPI(title="HU Connect API", version="0.3.0", lifespan=lifespan)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_pessoa(
    authorization: str = Header(default=None),
    db: Session = Depends(get_db),
) -> Pessoa:
    """
    Lê o cabeçalho 'Authorization: Bearer <token>', valida o token e
    retorna a pessoa autenticada. Usado como dependência nos endpoints
    que exigem login.
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Token não informado. Faça login em /auth/login.")

    token = authorization.removeprefix("Bearer ").strip()
    sessao = db.query(Sessao).filter(Sessao.token == token).first()

    if sessao is None:
        raise HTTPException(status_code=401, detail="Token inválido.")

    if token_expirado(sessao.criado_em):
        db.delete(sessao)
        db.commit()
        raise HTTPException(status_code=401, detail="Sessão expirada. Faça login novamente.")

    pessoa = db.get(Pessoa, sessao.pessoa_id)
    if pessoa is None:
        raise HTTPException(status_code=401, detail="Pessoa associada ao token não encontrada.")

    return pessoa


# ---------- Schemas de entrada (Pydantic) ----------

class LoginEntrada(BaseModel):
    email: str
    senha: str


class RecuperarSolicitarEntrada(BaseModel):
    email: str


class RecuperarConfirmarEntrada(BaseModel):
    email: str
    codigo: str
    nova_senha: str
    confirmacao: str


class InteracaoEntrada(BaseModel):
    destino_id: int
    tipo: str  # "like" ou "skip"


# ---------- Endpoints públicos ----------

@app.get("/")
def raiz():
    return {"status": "ok", "servico": "HU Connect API"}


@app.post("/auth/login")
def login(entrada: LoginEntrada, db: Session = Depends(get_db)):
    email = normalizar_email(entrada.email)
    credencial = db.query(Credencial).filter(Credencial.email == email).first()

    if credencial is None or not senha_confere(entrada.senha, credencial.senha_hash, credencial.salt):
        # mensagem genérica de propósito: não dizer se o e-mail existe ou não
        raise HTTPException(status_code=401, detail="E-mail ou senha incorretos.")

    # Hash no formato antigo? Atualiza agora que a senha foi confirmada.
    if precisa_atualizar_hash(credencial.senha_hash):
        credencial.senha_hash = criar_hash_senha(entrada.senha)
        credencial.salt = ""

    pessoa = db.get(Pessoa, credencial.pessoa_id)

    token = gerar_token()
    sessao = Sessao(token=token, pessoa_id=pessoa.id)
    db.add(sessao)
    db.commit()

    return {
        "token": token,
        "pessoa": {"id": pessoa.id, "nome": pessoa.nome, "email": pessoa.email},
    }


@app.post("/auth/recuperar/solicitar")
def recuperar_solicitar(entrada: RecuperarSolicitarEntrada, db: Session = Depends(get_db)):
    """
    Envia por e-mail um código de 6 dígitos para quem esqueceu a senha (ou
    ainda não tem uma). A resposta é SEMPRE a mesma, exista o e-mail ou não,
    para que ninguém descubra quem está cadastrado.
    """
    solicitar_codigo(db, entrada.email)
    return {"mensagem": "Se o e-mail estiver cadastrado, enviamos um código para ele."}


@app.post("/auth/recuperar/confirmar")
def recuperar_confirmar(entrada: RecuperarConfirmarEntrada, db: Session = Depends(get_db)):
    """Confere o código recebido por e-mail e grava a nova senha."""
    ok, mensagem = redefinir_senha(
        db, entrada.email, entrada.codigo, entrada.nova_senha, entrada.confirmacao
    )
    if not ok:
        raise HTTPException(status_code=400, detail=mensagem)
    return {"redefinida": True, "mensagem": mensagem}


@app.post("/auth/logout")
def logout(authorization: str = Header(default=None), db: Session = Depends(get_db)):
    if authorization and authorization.startswith("Bearer "):
        token = authorization.removeprefix("Bearer ").strip()
        sessao = db.query(Sessao).filter(Sessao.token == token).first()
        if sessao:
            db.delete(sessao)
            db.commit()
    return {"deslogado": True}


# ---------- Endpoints protegidos (exigem login) ----------

@app.get("/pessoas/me")
def meu_perfil(pessoa_atual: Pessoa = Depends(get_current_pessoa)):
    return {
        "id": pessoa_atual.id,
        "nome": pessoa_atual.nome,
        "email": pessoa_atual.email,
        "telefone": pessoa_atual.telefone,
        "vinculo": pessoa_atual.vinculo,
        "curso": pessoa_atual.curso,
        "instituicao": pessoa_atual.instituicao,
        "bio": pessoa_atual.bio,
        "interesses": pessoa_atual.interesses,
        "competencias": pessoa_atual.competencias,
        "objetivo": pessoa_atual.objetivo,
        "papel": pessoa_atual.papel,
    }


@app.get("/pessoas/{pessoa_id}")
def obter_pessoa(
    pessoa_id: int,
    db: Session = Depends(get_db),
    pessoa_atual: Pessoa = Depends(get_current_pessoa),
):
    pessoa = db.get(Pessoa, pessoa_id)
    if pessoa is None:
        raise HTTPException(status_code=404, detail="Pessoa não encontrada")
    return {
        "id": pessoa.id,
        "nome": pessoa.nome,
        "vinculo": pessoa.vinculo,
        "curso": pessoa.curso,
        "instituicao": pessoa.instituicao,
        "bio": pessoa.bio,
        "interesses": pessoa.interesses,
        "competencias": pessoa.competencias,
        "objetivo": pessoa.objetivo,
        "papel": pessoa.papel,
    }


@app.get("/recomendacoes")
def recomendacoes(
    limite: int = 10,
    db: Session = Depends(get_db),
    pessoa_atual: Pessoa = Depends(get_current_pessoa),
):
    """Retorna as pessoas mais compatíveis com quem está logado."""
    pessoa_id = pessoa_atual.id

    matches = (
        db.query(Match)
        .filter(or_(Match.pessoa_1_id == pessoa_id, Match.pessoa_2_id == pessoa_id))
        .order_by(Match.score_total.desc())
        .limit(limite)
        .all()
    )

    ja_vistas_ids = {
        i.destino_id for i in
        db.query(Interacao).filter(Interacao.origem_id == pessoa_id).all()
    }

    resultado = []
    for m in matches:
        outro_id = m.pessoa_2_id if m.pessoa_1_id == pessoa_id else m.pessoa_1_id
        if outro_id in ja_vistas_ids:
            continue
        outro = db.get(Pessoa, outro_id)
        resultado.append({
            "pessoa": {
                "id": outro.id,
                "nome": outro.nome,
                "curso": outro.curso,
                "vinculo": outro.vinculo,
                "bio": outro.bio,
            },
            "score_total": m.score_total,
            "detalhes": {
                "interesses": m.score_interesses,
                "atividade": m.score_atividade,
                "papel": m.score_papel,
                "competencias": m.score_competencias,
                "disponibilidade": m.score_disponibilidade,
            },
        })
    return resultado


@app.post("/interacoes")
def registrar_interacao(
    entrada: InteracaoEntrada,
    db: Session = Depends(get_db),
    pessoa_atual: Pessoa = Depends(get_current_pessoa),
):
    """
    Registra um like/skip. A pessoa de origem é sempre quem está logada
    (nunca confiamos em um 'origem_id' vindo do cliente) -- isso evita
    que alguém registre interações se fazendo passar por outra pessoa.
    """
    if entrada.tipo not in ("like", "skip"):
        raise HTTPException(status_code=400, detail="tipo deve ser 'like' ou 'skip'")

    # O registro e os avisos por e-mail (interesse recebido / conexão confirmada)
    # ficam em notificacoes.py, o mesmo código usado pela tela do Streamlit.
    try:
        resultado = registrar_interacao_com_aviso(db, pessoa_atual.id, entrada.destino_id, entrada.tipo)
    except ValueError as erro:
        raise HTTPException(status_code=404, detail=str(erro))

    contato = None
    if resultado.conexao and resultado.outro is not None:
        contato = {
            "nome": resultado.outro.nome,
            "email": resultado.outro.email,
            "telefone": resultado.outro.telefone,
        }

    return {"registrado": resultado.registrada, "conexao": resultado.conexao, "contato": contato}


@app.get("/interacoes/ignorados")
def listar_ignorados(
    db: Session = Depends(get_db),
    pessoa_atual: Pessoa = Depends(get_current_pessoa),
):
    """
    Lista pessoas que foram ignoradas (skip) e que ainda não viraram
    like depois disso -- ou seja, considera sempre a interação MAIS
    RECENTE entre a pessoa logada e cada outra pessoa.
    """
    interacoes = (
        db.query(Interacao)
        .filter(Interacao.origem_id == pessoa_atual.id)
        .order_by(Interacao.id.asc())
        .all()
    )

    # guarda só a interação mais recente por destino (a última da lista, já em ordem)
    status_por_destino = {}
    for i in interacoes:
        status_por_destino[i.destino_id] = i.tipo

    ignorados_ids = [destino_id for destino_id, tipo in status_por_destino.items() if tipo == "skip"]

    resultado = []
    for outro_id in ignorados_ids:
        outro = db.get(Pessoa, outro_id)
        if outro is None:
            continue
        match = (
            db.query(Match)
            .filter(
                or_(
                    (Match.pessoa_1_id == pessoa_atual.id) & (Match.pessoa_2_id == outro_id),
                    (Match.pessoa_1_id == outro_id) & (Match.pessoa_2_id == pessoa_atual.id),
                )
            )
            .first()
        )
        resultado.append({
            "pessoa": {"id": outro.id, "nome": outro.nome, "curso": outro.curso, "vinculo": outro.vinculo},
            "score_total": match.score_total if match else None,
        })

    resultado.sort(key=lambda r: r["score_total"] or 0, reverse=True)
    return resultado


@app.get("/conexoes-confirmadas")
def matches_confirmados(
    db: Session = Depends(get_db),
    pessoa_atual: Pessoa = Depends(get_current_pessoa),
):
    """Lista pessoas com quem quem está logado tem uma conexão mútua confirmada."""
    pessoa_id = pessoa_atual.id

    likes_dados = {
        i.destino_id for i in
        db.query(Interacao).filter(
            Interacao.origem_id == pessoa_id, Interacao.tipo == "like"
        ).all()
    }
    likes_recebidos = {
        i.origem_id for i in
        db.query(Interacao).filter(
            Interacao.destino_id == pessoa_id, Interacao.tipo == "like"
        ).all()
    }
    ids_match = likes_dados & likes_recebidos

    resultado = []
    for outro_id in ids_match:
        outro = db.get(Pessoa, outro_id)
        if outro:
            resultado.append({
                "id": outro.id,
                "nome": outro.nome,
                "curso": outro.curso,
                "email": outro.email,
                "telefone": outro.telefone,
            })
    return resultado
