"""
Motor de compatibilidade do HU Conecta.

Ideia central: cada campo "de múltipla escolha" (interesses, competências,
objetivo, disponibilidade) vira um conjunto (set) de códigos, e a maioria
é comparada usando o índice de Jaccard (interseção / união) -- uma forma
simples de medir o quanto dois conjuntos têm em comum.

O campo "papel" é tratado de um jeito diferente dos outros: não é sobre
ter o MESMO papel, e sim sobre ter papéis que se COMPLEMENTAM -- um
"orientando" combina com um "orientador", não com outro "orientando".
Isso é o que dá o efeito de "match" entre perfis diferentes (ex: aluno
de TI que quer orientação x professor de Medicina que quer orientar).

Códigos esperados do campo `papel` (definidos em dados/opcoes.json):
    1 - Quero ser orientando(a)
    2 - Quero ser orientador(a)
    3 - Quero colaborar como participante
    4 - Quero um(a) colaborador(a) para meu projeto
    5 - Quero fazer networking
"""

from dataclasses import dataclass


PESOS = {
    "interesses": 0.25,       # área de interesse em comum
    "atividade": 0.15,        # objetivo (TCC, IC, etc.) em comum
    "papel": 0.30,             # complementaridade de papel -- o mais importante
    "competencias": 0.15,
    "disponibilidade": 0.15,
}

# Para cada código de papel, qual código complementar a pessoa está buscando
# no outro perfil. Códigos sem complemento natural (ex: networking) mapeiam
# para si mesmos, já que "quero networking" combina com "quero networking".
PAPEL_COMPLEMENTAR = {
    "1": "2",  # orientando  -> busca orientador
    "2": "1",  # orientador  -> busca orientando
    "3": "4",  # colaborador participante -> busca quem precisa de colaborador
    "4": "3",  # quer colaborador -> busca colaborador participante
    "5": "5",  # networking  -> busca networking
}


def to_set(campo: str) -> set:
    """Converte 'campo' do formato '1,3,4' em um set {'1','3','4'}."""
    if not campo:
        return set()
    return {c.strip() for c in campo.split(",") if c.strip()}


def similaridade_jaccard(a: set, b: set) -> float:
    """Retorna um valor de 0 a 1 -- quanto maior, mais os dois conjuntos têm em comum."""
    if not a or not b:
        return 0.0
    intersecao = len(a & b)
    uniao = len(a | b)
    return intersecao / uniao if uniao else 0.0


def score_papel_complementar(papel_a: set, papel_b: set) -> float:
    """
    Mede o quanto os papéis escolhidos por A e por B se complementam.
    Ex: se A marcou "orientando" (1), o que A busca no outro é "orientador" (2).
    Se B realmente marcou "orientador", isso conta como complementaridade.
    Calculado nos dois sentidos e tirada a média (0 a 1).
    """
    esperado_por_a = {PAPEL_COMPLEMENTAR.get(codigo, codigo) for codigo in papel_a}
    esperado_por_b = {PAPEL_COMPLEMENTAR.get(codigo, codigo) for codigo in papel_b}

    match_ab = len(esperado_por_a & papel_b) / len(papel_a) if papel_a else 0.0
    match_ba = len(esperado_por_b & papel_a) / len(papel_b) if papel_b else 0.0
    return (match_ab + match_ba) / 2


@dataclass
class ResultadoCompatibilidade:
    score_total: float
    score_interesses: float
    score_atividade: float
    score_papel: float
    score_competencias: float
    score_disponibilidade: float

    def to_dict(self) -> dict:
        return {
            "score_total": self.score_total,
            "score_interesses": self.score_interesses,
            "score_atividade": self.score_atividade,
            "score_papel": self.score_papel,
            "score_competencias": self.score_competencias,
            "score_disponibilidade": self.score_disponibilidade,
        }


def calcular_compatibilidade(pessoa_a, pessoa_b) -> ResultadoCompatibilidade:
    """
    Recebe dois objetos Pessoa (do models.py) e retorna os scores
    de compatibilidade entre eles, em escala de 0 a 100.
    """
    interesses_a = to_set(pessoa_a.interesses)
    interesses_b = to_set(pessoa_b.interesses)
    competencias_a = to_set(pessoa_a.competencias)
    competencias_b = to_set(pessoa_b.competencias)
    objetivo_a = to_set(pessoa_a.objetivo)
    objetivo_b = to_set(pessoa_b.objetivo)
    papel_a = to_set(pessoa_a.papel)
    papel_b = to_set(pessoa_b.papel)
    disp_a = to_set(pessoa_a.disp_dias) | to_set(pessoa_a.disp_periodo)
    disp_b = to_set(pessoa_b.disp_dias) | to_set(pessoa_b.disp_periodo)

    score_interesses = similaridade_jaccard(interesses_a, interesses_b)
    score_atividade = similaridade_jaccard(objetivo_a, objetivo_b)
    score_papel = score_papel_complementar(papel_a, papel_b)
    score_competencias = similaridade_jaccard(competencias_a, competencias_b)
    score_disponibilidade = similaridade_jaccard(disp_a, disp_b)

    total = (
        score_interesses * PESOS["interesses"]
        + score_atividade * PESOS["atividade"]
        + score_papel * PESOS["papel"]
        + score_competencias * PESOS["competencias"]
        + score_disponibilidade * PESOS["disponibilidade"]
    )

    return ResultadoCompatibilidade(
        score_total=round(total * 100, 1),
        score_interesses=round(score_interesses * 100, 1),
        score_atividade=round(score_atividade * 100, 1),
        score_papel=round(score_papel * 100, 1),
        score_competencias=round(score_competencias * 100, 1),
        score_disponibilidade=round(score_disponibilidade * 100, 1),
    )
