"""
Modelos do banco de dados do HU Connect (versão SQL, sem REDCap).

O banco é a ÚNICA fonte da verdade: guarda os perfis cadastrados pelo próprio
sistema, as senhas (só em hash), os scores de compatibilidade, os likes/skips,
os códigos de confirmação/recuperação e o registro de avisos enviados.

O banco padrão é SQLite (um arquivo), mas qualquer banco SQL suportado pelo
SQLAlchemy serve (PostgreSQL, SQL Server, MySQL...) -- basta trocar a variável
DATABASE_URL no .env (veja .env.example).
"""

from sqlalchemy import Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import declarative_base
from datetime import datetime

Base = declarative_base()


class Pessoa(Base):
    """Perfil de uma pessoa, preenchido no cadastro do próprio sistema."""
    __tablename__ = "pessoas"

    id = Column(Integer, primary_key=True)
    nome = Column(String, default="")
    email = Column(String, default="", unique=True)
    telefone = Column(String, default="")
    vinculo = Column(String, default="")
    curso = Column(String, default="")
    instituicao = Column(String, default="")
    bio = Column(String, default="")
    lattes = Column(String, default="")           # link do Currículo Lattes

    # Respostas do formulário em JSON (códigos escolhidos). Serve para preencher
    # de novo o formulário na edição do perfil, sem depender dos textos acima.
    dados_form = Column(Text, default="")

    # Campos "de conjunto" guardados como string separada por vírgula, ex: "1,3,4"
    interesses = Column(String, default="")       # área de interesse acadêmico/profissional
    competencias = Column(String, default="")
    objetivo = Column(String, default="")          # tipo de atividade buscada (TCC, IC, etc.)
    papel = Column(String, default="")             # papel desejado (orientando, orientador, etc.)
    disp_dias = Column(String, default="")
    disp_periodo = Column(String, default="")

    atualizado_em = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Credencial(Base):
    """
    Login (e-mail + senha) de uma pessoa. Fica separado da tabela Pessoa
    de propósito: dados de perfil e dados de acesso não se misturam.
    A senha é guardada só em hash (veja auth.py).
    """
    __tablename__ = "credenciais"

    id = Column(Integer, primary_key=True)
    pessoa_id = Column(Integer, ForeignKey("pessoas.id"), unique=True)
    email = Column(String, unique=True, nullable=False)

    # Formato atual: 'pbkdf2_sha256$<iterações>$<salt>$<hash>' (tudo numa string só,
    # veja auth.py). Nesse caso `salt` fica vazio. Credenciais antigas guardam só o
    # hash aqui e o salt na coluna ao lado -- continuam funcionando e são
    # atualizadas para o formato novo no próximo login.
    senha_hash = Column(String, nullable=False)
    salt = Column(String, nullable=False, default="")
    criado_em = Column(DateTime, default=datetime.utcnow)


class Sessao(Base):
    """Token de sessão emitido após um login bem-sucedido."""
    __tablename__ = "sessoes"

    id = Column(Integer, primary_key=True)
    token = Column(String, unique=True, nullable=False)
    pessoa_id = Column(Integer, ForeignKey("pessoas.id"))
    criado_em = Column(DateTime, default=datetime.utcnow)


class Match(Base):
    """Score de compatibilidade calculado entre duas pessoas."""
    __tablename__ = "matches"
    __table_args__ = (UniqueConstraint("pessoa_1_id", "pessoa_2_id", name="uq_par_pessoas"),)

    id = Column(Integer, primary_key=True)
    pessoa_1_id = Column(Integer, ForeignKey("pessoas.id"))
    pessoa_2_id = Column(Integer, ForeignKey("pessoas.id"))

    score_total = Column(Float, default=0.0)
    score_interesses = Column(Float, default=0.0)
    score_atividade = Column(Float, default=0.0)       # objetivo em comum (TCC, IC, etc.)
    score_papel = Column(Float, default=0.0)            # complementaridade de papel (orientando <-> orientador)
    score_competencias = Column(Float, default=0.0)
    score_disponibilidade = Column(Float, default=0.0)

    calculado_em = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Interacao(Base):
    """Registro de 'like' ou 'skip' de uma pessoa em relação a outra."""
    __tablename__ = "interacoes"

    id = Column(Integer, primary_key=True)
    origem_id = Column(Integer, ForeignKey("pessoas.id"))
    destino_id = Column(Integer, ForeignKey("pessoas.id"))
    tipo = Column(String)  # "like" ou "skip"
    criado_em = Column(DateTime, default=datetime.utcnow)


class CodigoRecuperacao(Base):
    """
    Código de 6 dígitos enviado por e-mail para quem pediu recuperação de senha.
    Guardamos só o HASH do código (nunca o código em si), com validade curta e
    limite de tentativas erradas.
    """
    __tablename__ = "codigos_recuperacao"

    id = Column(Integer, primary_key=True)
    pessoa_id = Column(Integer, ForeignKey("pessoas.id"), index=True)
    codigo_hash = Column(String, nullable=False)
    salt = Column(String, nullable=False)
    criado_em = Column(DateTime, default=datetime.utcnow)
    expira_em = Column(DateTime, nullable=False)
    tentativas = Column(Integer, default=0)
    usado = Column(Boolean, default=False)


class Notificacao(Base):
    """
    Registro de e-mails de aviso já enviados (interesse recebido / conexão
    confirmada). Serve para NÃO mandar o mesmo aviso duas vezes: a combinação
    (tipo, destinatário, outra pessoa) é única.
    """
    __tablename__ = "notificacoes"
    __table_args__ = (
        UniqueConstraint("tipo", "destinatario_id", "outro_id", name="uq_notificacao"),
    )

    id = Column(Integer, primary_key=True)
    tipo = Column(String, nullable=False)  # "interesse" ou "conexao"
    destinatario_id = Column(Integer, ForeignKey("pessoas.id"), nullable=False)
    outro_id = Column(Integer, ForeignKey("pessoas.id"), nullable=False)
    enviado_em = Column(DateTime, default=datetime.utcnow)


class CadastroPendente(Base):
    """
    Cadastro que ainda aguarda a confirmação do e-mail. A pessoa só passa a
    existir (tabelas Pessoa e Credencial) depois de digitar o código de 6 dígitos
    enviado para o e-mail dela -- assim ninguém cria conta com o e-mail de outra
    pessoa. Guarda os dados do formulário, o hash da senha e o hash do código.
    """
    __tablename__ = "cadastros_pendentes"

    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, nullable=False)
    dados_json = Column(Text, nullable=False)
    senha_hash = Column(String, nullable=False)
    codigo_hash = Column(String, nullable=False)
    salt = Column(String, nullable=False)
    criado_em = Column(DateTime, default=datetime.utcnow)
    expira_em = Column(DateTime, nullable=False)
    tentativas = Column(Integer, default=0)
