"""
Regras de "like/skip" e avisos por e-mail.

Este é o ÚNICO lugar que registra interações. Tanto a tela (Streamlit) quanto
a API (FastAPI) chamam `registrar_interacao`, então as duas se comportam igual:

- Alguém dá "like" e a outra pessoa AINDA NÃO retribuiu
    -> e-mail para a outra pessoa: "alguém tem interesse em você".
       (Só é enviado se ela ainda não tomou nenhuma decisão sobre quem curtiu.)
- Alguém dá "like" e a outra pessoa JÁ tinha dado like
    -> conexão confirmada: e-mail para as DUAS, já com o contato de cada uma.
- Cada aviso é enviado no máximo uma vez por par de pessoas (tabela Notificacao).

Se o e-mail falhar (SMTP fora do ar, por exemplo), o like/skip é gravado do
mesmo jeito -- o aviso é que não sai.

Variável opcional no .env:
    NOTIFICAR_QUEM_DEMONSTROU_INTERESSE=true
Com 'false', o aviso de interesse descreve o perfil (vínculo/curso/instituição)
mas não diz o NOME de quem curtiu.
"""

import os
from dataclasses import dataclass

from sqlalchemy.exc import IntegrityError

import email_service
from models import Interacao, Notificacao, Pessoa
from rotulos import resumo_interesses


@dataclass
class ResultadoInteracao:
    registrada: bool
    conexao: bool = False          # True se virou conexão mútua agora
    outro: Pessoa | None = None    # a outra pessoa (útil para mostrar o contato)
    emails_enviados: int = 0


def _revelar_nome() -> bool:
    return os.getenv("NOTIFICAR_QUEM_DEMONSTROU_INTERESSE", "true").strip().lower() in (
        "1", "true", "sim", "yes", "on"
    )


def _dados_publicos(p: Pessoa) -> dict:
    return {
        "nome": p.nome, "vinculo": p.vinculo, "curso": p.curso, "instituicao": p.instituicao,
        "email": p.email, "telefone": p.telefone,
    }


def _ja_notificado(db, tipo: str, destinatario_id: int, outro_id: int) -> bool:
    return (
        db.query(Notificacao)
        .filter(
            Notificacao.tipo == tipo,
            Notificacao.destinatario_id == destinatario_id,
            Notificacao.outro_id == outro_id,
        )
        .first()
        is not None
    )


def _marcar_notificado(db, tipo: str, destinatario_id: int, outro_id: int) -> None:
    db.add(Notificacao(tipo=tipo, destinatario_id=destinatario_id, outro_id=outro_id))
    try:
        db.commit()
    except IntegrityError:  # outra execução marcou ao mesmo tempo -- tudo bem
        db.rollback()


def _enviar_aviso(db, tipo: str, destinatario: Pessoa, outro: Pessoa) -> bool:
    """Monta e envia um aviso, respeitando o 'só uma vez'. True se enviou."""
    if not destinatario.email or _ja_notificado(db, tipo, destinatario.id, outro.id):
        return False

    em_comum = resumo_interesses(destinatario, outro)["em_comum"]
    if tipo == "conexao":
        assunto, texto, html = email_service.montar_email_conexao(
            destinatario.nome or "", _dados_publicos(outro), em_comum
        )
    else:
        assunto, texto, html = email_service.montar_email_novo_interesse(
            destinatario.nome or "", _dados_publicos(outro), em_comum, _revelar_nome()
        )

    if email_service.enviar_email(destinatario.email, assunto, texto, html):
        _marcar_notificado(db, tipo, destinatario.id, outro.id)
        return True
    return False


def registrar_interacao(db, origem_id: int, destino_id: int, tipo: str) -> ResultadoInteracao:
    """
    Grava um 'like' ou 'skip' de origem_id para destino_id e dispara os avisos.
    A origem deve ser SEMPRE a pessoa autenticada (nunca um valor vindo do cliente).
    """
    if tipo not in ("like", "skip"):
        raise ValueError("tipo deve ser 'like' ou 'skip'")
    if origem_id == destino_id:
        return ResultadoInteracao(registrada=False)

    origem = db.get(Pessoa, origem_id)
    destino = db.get(Pessoa, destino_id)
    if origem is None or destino is None:
        raise ValueError("Pessoa não encontrada.")

    # A outra pessoa já tomou alguma decisão sobre mim? (calculado ANTES de gravar)
    destino_ja_decidiu = (
        db.query(Interacao)
        .filter(Interacao.origem_id == destino_id, Interacao.destino_id == origem_id)
        .first()
        is not None
    )

    db.add(Interacao(origem_id=origem_id, destino_id=destino_id, tipo=tipo))
    db.commit()

    if tipo == "skip":
        return ResultadoInteracao(registrada=True, outro=destino)

    reciproco = (
        db.query(Interacao)
        .filter(
            Interacao.origem_id == destino_id,
            Interacao.destino_id == origem_id,
            Interacao.tipo == "like",
        )
        .first()
        is not None
    )

    enviados = 0
    if reciproco:
        # Conexão confirmada: avisa as duas pessoas.
        enviados += _enviar_aviso(db, "conexao", origem, destino)
        enviados += _enviar_aviso(db, "conexao", destino, origem)
    elif not destino_ja_decidiu:
        # Interesse "solto": avisa só quem recebeu.
        enviados += _enviar_aviso(db, "interesse", destino, origem)

    return ResultadoInteracao(
        registrada=True, conexao=reciproco, outro=destino, emails_enviados=enviados
    )


def ids_que_demonstraram_interesse(db, pessoa_id: int) -> set:
    """
    Pessoas que deram 'like' em mim e sobre as quais eu ainda não decidi nada
    (nem like, nem skip). É o que a tela usa para o aviso "N pessoas têm
    interesse em você" e para destacar esses perfis.
    """
    curtiram = {
        i.origem_id
        for i in db.query(Interacao)
        .filter(Interacao.destino_id == pessoa_id, Interacao.tipo == "like")
        .all()
    }
    if not curtiram:
        return set()
    ja_decididos = {
        i.destino_id for i in db.query(Interacao).filter(Interacao.origem_id == pessoa_id).all()
    }
    return curtiram - ja_decididos
