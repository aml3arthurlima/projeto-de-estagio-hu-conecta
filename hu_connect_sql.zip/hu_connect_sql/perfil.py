"""
Regras do formulário de cadastro/edição de perfil (sem banco, sem tela).

O formulário produz um dicionário `dados` com CÓDIGOS escolhidos. Este módulo:
  - valida esse dicionário (`validar_dados`);
  - converte para os campos da tabela Pessoa no formato que o motor de
    compatibilidade (matching.py) já espera (`para_campos_pessoa`).

Formato de `dados`:
    nome, email, telefone, lattes     -> texto
    vinculo, curso                    -> um código (texto), curso pode ser ""
    instituicoes                      -> lista de códigos ("1","2","99"...)
    outras_instituicoes, bio          -> texto
    objetivo, papel, competencias     -> listas de códigos
    interesses                        -> lista de chaves "campo:código",
                                         ex.: ["interesses:3", "subareas_ti:5"]
    disp_dias, disp_periodo           -> listas de códigos
"""

import re

from auth import dominio_permitido, normalizar_email
from rotulos import opcoes, rotulo

# Cada grande área de "interesses" tem um grupo de subáreas.
# código da grande área -> campo das subáreas
SUBAREAS_POR_AREA = {
    "1": "subareas_saude",
    "2": "subareas_biologicas",
    "3": "subareas_ti",
    "4": "subareas_engenharia",
    "5": "subareas_gestao",
}

CAMPOS_INTERESSE = ["interesses"] + list(SUBAREAS_POR_AREA.values())

LIMITE_BIO = 1000
LIMITE_NOME = 120


def dados_vazios() -> dict:
    return {
        "nome": "", "email": "", "telefone": "", "lattes": "",
        "vinculo": "", "curso": "", "instituicoes": [], "outras_instituicoes": "",
        "bio": "", "objetivo": [], "papel": [], "competencias": [],
        "interesses": [], "disp_dias": [], "disp_periodo": [],
    }


def normalizar_telefone(telefone: str) -> str:
    """Só os dígitos. Ex.: '(83) 99999-1234' -> '83999991234'."""
    return re.sub(r"\D", "", telefone or "")


def chaves_interesse_validas() -> set:
    validas = set()
    for campo in CAMPOS_INTERESSE:
        validas |= {f"{campo}:{c}" for c in opcoes(campo)}
    return validas


def _todos_validos(codigos: list, campo: str) -> bool:
    validos = set(opcoes(campo))
    return all(c in validos for c in codigos)


def validar_dados(dados: dict, validar_dominio_do_email: bool = True) -> list:
    """Devolve a lista de mensagens de erro (vazia se estiver tudo certo)."""
    erros = []
    d = {**dados_vazios(), **dados}

    nome = (d["nome"] or "").strip()
    if len(nome) < 3:
        erros.append("Informe seu nome completo.")
    elif len(nome) > LIMITE_NOME:
        erros.append(f"O nome pode ter no máximo {LIMITE_NOME} caracteres.")

    email = normalizar_email(d["email"])
    if not email or "@" not in email:
        erros.append("Informe seu e-mail institucional.")
    elif validar_dominio_do_email and not dominio_permitido(email):
        erros.append("Use seu e-mail institucional (de uma das instituições aceitas).")

    telefone = normalizar_telefone(d["telefone"])
    if len(telefone) not in (10, 11):
        erros.append("Informe o telefone com DDD (10 ou 11 dígitos).")

    lattes = (d["lattes"] or "").strip()
    if not lattes:
        erros.append("Informe o link do seu Currículo Lattes.")
    elif not re.match(r"^https?://\S+$", lattes) or len(lattes) > 300:
        erros.append("O link do Lattes deve começar com http:// ou https:// e não ter espaços.")

    if d["vinculo"] not in opcoes("vinculo"):
        erros.append("Escolha o seu vínculo.")
    if d["curso"] and d["curso"] not in opcoes("curso"):
        erros.append("Curso inválido.")

    if not d["instituicoes"]:
        erros.append("Escolha ao menos uma instituição de vínculo.")
    elif not _todos_validos(d["instituicoes"], "instituicao_de_vinculo"):
        erros.append("Instituição inválida.")
    elif "99" in d["instituicoes"] and not (d["outras_instituicoes"] or "").strip():
        erros.append("Você marcou \"Outra\": escreva o nome da instituição.")

    if len(d["bio"] or "") > LIMITE_BIO:
        erros.append(f"A bio pode ter no máximo {LIMITE_BIO} caracteres.")

    if not d["interesses"]:
        erros.append("Escolha ao menos um interesse.")
    elif not set(d["interesses"]) <= chaves_interesse_validas():
        erros.append("Interesse inválido.")

    if not d["papel"]:
        erros.append("Escolha ao menos um papel (é com ele que calculamos a compatibilidade).")
    for campo_dados, campo_opcoes, texto in [
        ("papel", "papel", "papel"),
        ("objetivo", "objetivo", "objetivo"),
        ("competencias", "competencias", "competência"),
    ]:
        if d[campo_dados] and not _todos_validos(d[campo_dados], campo_opcoes):
            erros.append(f"Valor inválido em {texto}.")

    if not d["disp_dias"]:
        erros.append("Escolha ao menos um dia de disponibilidade.")
    elif not _todos_validos(d["disp_dias"], "disp_dias"):
        erros.append("Dia de disponibilidade inválido.")
    if not d["disp_periodo"]:
        erros.append("Escolha ao menos um período de disponibilidade.")
    elif not _todos_validos(d["disp_periodo"], "disp_periodo"):
        erros.append("Período de disponibilidade inválido.")

    return erros


def _juntar(codigos: list) -> str:
    return ",".join(sorted(set(codigos)))


def instituicao_em_texto(dados: dict) -> str:
    partes = []
    for codigo in dados.get("instituicoes", []):
        if codigo == "99":
            partes.append((dados.get("outras_instituicoes") or "").strip() or "Outra")
        else:
            partes.append(rotulo("instituicao_de_vinculo", codigo))
    return ", ".join(partes)


def para_campos_pessoa(dados: dict) -> dict:
    """Converte o formulário nas colunas da tabela Pessoa."""
    d = {**dados_vazios(), **dados}
    return {
        "nome": d["nome"].strip(),
        "email": normalizar_email(d["email"]),
        "telefone": normalizar_telefone(d["telefone"]),
        "lattes": d["lattes"].strip(),
        "vinculo": rotulo("vinculo", d["vinculo"]) if d["vinculo"] else "",
        "curso": rotulo("curso", d["curso"]) if d["curso"] else "",
        "instituicao": instituicao_em_texto(d),
        "bio": (d["bio"] or "").strip(),
        "interesses": _juntar(d["interesses"]),
        "competencias": _juntar(d["competencias"]),
        "objetivo": _juntar(d["objetivo"]),
        "papel": _juntar(d["papel"]),
        "disp_dias": _juntar(d["disp_dias"]),
        "disp_periodo": _juntar(d["disp_periodo"]),
    }
