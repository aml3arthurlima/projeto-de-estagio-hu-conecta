"""
Cria algumas pessoas FICTÍCIAS para você ter com quem testar o sistema.

    python database.py
    python popular_exemplo.py

Todas têm a senha "teste1234" e e-mail @example.com (domínio reservado, nunca
recebe e-mail de verdade). Para ver os avisos por e-mail dos testes, use
EMAIL_MODO=console no .env. Apague essas pessoas antes de usar o sistema de verdade
(cada uma pode excluir a própria conta no app, ou apague o arquivo do banco).
"""
from auth import criar_hash_senha
from cadastro import criar_pessoa
from database import SessionLocal, init_db
from models import Pessoa

BASE = {"lattes": "http://lattes.cnpq.br/0000000000000000", "outras_instituicoes": "", "objetivo": ["1"],
        "disp_dias": ["segunda", "quarta"], "disp_periodo": ["tarde"], "bio": "Pessoa fictícia para testes."}

EXEMPLOS = [
    dict(nome="Ana Exemplo", email="ana.exemplo@example.com", telefone="83999990001", vinculo="1", curso="4",
         instituicoes=["3"], papel=["1"], competencias=["1", "2"],
         interesses=["interesses:3", "subareas_ti:1", "subareas_ti:2"]),
    dict(nome="Bruno Exemplo", email="bruno.exemplo@example.com", telefone="83999990002", vinculo="6", curso="",
         instituicoes=["1", "2"], papel=["2"], competencias=["3"],
         interesses=["interesses:1", "interesses:3", "subareas_ti:1"]),
    dict(nome="Carla Exemplo", email="carla.exemplo@example.com", telefone="83999990003", vinculo="3", curso="2",
         instituicoes=["1"], papel=["3", "5"], competencias=["3"],
         interesses=["interesses:1", "subareas_saude:1"]),
    dict(nome="Diego Exemplo", email="diego.exemplo@example.com", telefone="83999990004", vinculo="4", curso="",
         instituicoes=["1"], papel=["4"], competencias=["1"],
         interesses=["interesses:3", "interesses:4", "subareas_ti:2"]),
]

if __name__ == "__main__":
    init_db()
    db = SessionLocal()
    try:
        for exemplo in EXEMPLOS:
            if db.query(Pessoa).filter(Pessoa.email == exemplo["email"]).first():
                print(f"já existe: {exemplo['email']}")
                continue
            criar_pessoa(db, {**BASE, **exemplo}, criar_hash_senha("teste1234"))
            print(f"criado: {exemplo['nome']} ({exemplo['email']})")
    finally:
        db.close()
    print('Pronto. Entre com qualquer um desses e-mails e a senha "teste1234".')
