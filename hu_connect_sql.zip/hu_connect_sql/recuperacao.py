"""
Recuperação de senha por e-mail.

Fluxo:
  1. `solicitar_codigo(db, email)` -- se o e-mail pertence a uma pessoa
     cadastrada, manda um código de 6 dígitos para ELE (e só para ele).
  2. `redefinir_senha(db, email, codigo, nova, confirmacao)` -- confere o
     código e grava a nova senha.

Cuidados de segurança:
- A tela sempre responde a mesma coisa em (1), exista ou não o e-mail,
  para ninguém descobrir quem está cadastrado.
- Código guardado só como hash, validade de 15 min, uso único, no máximo
  5 tentativas erradas e um pedido novo só depois de 60 s.
- Quem prova que recebe o e-mail pode definir a senha -- isso também
  substitui a antiga aba "Primeiro acesso", que deixava QUALQUER pessoa
  que soubesse o e-mail de outra criar a senha dela.
- Ao trocar a senha, as sessões abertas da API dessa pessoa são encerradas e
  um aviso "sua senha foi alterada" vai para o e-mail dela.
"""

from datetime import datetime

import email_service
from auth import (
    INTERVALO_MINIMO_REENVIO, MAX_TENTATIVAS_CODIGO, VALIDADE_CODIGO,
    codigo_confere, criar_hash_senha, dominio_permitido, gerar_codigo_recuperacao,
    gerar_salt, hash_codigo, normalizar_email, validar_nova_senha,
)
from models import CodigoRecuperacao, Credencial, Pessoa, Sessao

MSG_CODIGO_INVALIDO = "Código inválido ou expirado. Confira o código ou peça um novo."


def _pessoa_por_email(db, email: str):
    if not dominio_permitido(email):
        return None
    return db.query(Pessoa).filter(Pessoa.email == email).first()


def solicitar_codigo(db, email: str) -> None:
    """
    Envia o código de recuperação, se couber. Não devolve nada de propósito:
    quem chama deve mostrar sempre a mesma mensagem genérica.
    """
    email = normalizar_email(email)
    pessoa = _pessoa_por_email(db, email)
    if pessoa is None:
        return

    agora = datetime.utcnow()
    anterior = (
        db.query(CodigoRecuperacao)
        .filter(CodigoRecuperacao.pessoa_id == pessoa.id)
        .order_by(CodigoRecuperacao.id.desc())
        .first()
    )
    if anterior and agora - anterior.criado_em < INTERVALO_MINIMO_REENVIO:
        return  # pedido muito seguido: ignora em silêncio

    # Só vale o código mais recente.
    db.query(CodigoRecuperacao).filter(CodigoRecuperacao.pessoa_id == pessoa.id).delete()

    codigo = gerar_codigo_recuperacao()
    salt = gerar_salt()
    db.add(CodigoRecuperacao(
        pessoa_id=pessoa.id,
        codigo_hash=hash_codigo(codigo, salt),
        salt=salt,
        expira_em=agora + VALIDADE_CODIGO,
    ))
    db.commit()

    assunto, texto, html = email_service.montar_email_codigo(
        pessoa.nome or "", codigo, int(VALIDADE_CODIGO.total_seconds() // 60)
    )
    email_service.enviar_email(pessoa.email, assunto, texto, html)


def redefinir_senha(db, email: str, codigo: str, nova_senha: str, confirmacao: str) -> tuple:
    """Devolve (ok: bool, mensagem: str)."""
    email = normalizar_email(email)

    erro = validar_nova_senha(nova_senha, confirmacao)
    if erro:
        return False, erro

    pessoa = _pessoa_por_email(db, email)
    registro = None
    if pessoa is not None:
        registro = (
            db.query(CodigoRecuperacao)
            .filter(CodigoRecuperacao.pessoa_id == pessoa.id, CodigoRecuperacao.usado.is_(False))
            .order_by(CodigoRecuperacao.id.desc())
            .first()
        )

    if (
        registro is None
        or datetime.utcnow() > registro.expira_em
        or (registro.tentativas or 0) >= MAX_TENTATIVAS_CODIGO
    ):
        return False, MSG_CODIGO_INVALIDO

    if not codigo_confere(codigo or "", registro.salt, registro.codigo_hash):
        registro.tentativas = (registro.tentativas or 0) + 1
        db.commit()
        return False, MSG_CODIGO_INVALIDO

    # ---- Código correto: grava a nova senha ----
    novo_hash = criar_hash_senha(nova_senha)
    credencial = db.query(Credencial).filter(Credencial.pessoa_id == pessoa.id).first()
    if credencial is None:
        credencial = Credencial(pessoa_id=pessoa.id, email=pessoa.email, senha_hash=novo_hash, salt="")
        db.add(credencial)
    else:
        credencial.email = pessoa.email
        credencial.senha_hash = novo_hash
        credencial.salt = ""

    db.query(CodigoRecuperacao).filter(CodigoRecuperacao.pessoa_id == pessoa.id).delete()
    db.query(Sessao).filter(Sessao.pessoa_id == pessoa.id).delete()  # encerra sessões da API
    db.commit()

    assunto, texto, html = email_service.montar_email_senha_alterada(pessoa.nome or "")
    email_service.enviar_email(pessoa.email, assunto, texto, html)

    return True, "Senha redefinida com sucesso! Agora é só entrar na aba \"Entrar\"."
