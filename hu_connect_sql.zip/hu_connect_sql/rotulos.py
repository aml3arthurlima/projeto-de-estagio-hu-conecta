"""
Textos das opções e resumo de interesses.

No banco os campos de múltipla escolha ficam guardados como CÓDIGOS
(ex.: interesses = "interesses:3,subareas_ti:5"). Este módulo converte o
código no texto legível ("Banco de Dados", "Python"...) e é também a fonte
das opções do formulário de cadastro.

As opções ficam em dados/opcoes.json -- um JSON simples {campo: {código: texto}}
que você pode editar à mão para mudar a lista de áreas, competências etc.
(se mudar códigos que já foram usados por pessoas cadastradas, os perfis
antigos passam a mostrar o texto errado: prefira ACRESCENTAR opções novas).
Dá para regerar o arquivo a partir de um CSV com `python gerar_opcoes.py`.

Papel, dias e períodos têm textos fixos neste arquivo.
Se faltar texto para algum código, aparece um texto genérico
(ex.: "Tecnologia da informação · opção 5") em vez de quebrar a tela.
"""

import csv
import json
import os
from functools import lru_cache

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CAMINHO_OPCOES = os.path.join(BASE_DIR, "dados", "opcoes.json")

# Campos checkbox que formam o perfil de "interesses",
# com um nome de grupo só para organizar a exibição e para o texto genérico.
GRUPOS_INTERESSE = {
    "interesses": "Grande área",
    "subareas_saude": "Saúde",
    "subareas_biologicas": "Ciências biológicas",
    "subareas_ti": "Tecnologia da informação",
    "subareas_engenharia": "Engenharia",
    "subareas_gestao": "Gestão",
}

# Textos fixos (papel vem do matching.py; dias e períodos são os valores usados no cadastro).
PAPEL_LABELS = {
    "1": "Quero ser orientando(a)",
    "2": "Quero ser orientador(a)",
    "3": "Quero colaborar como participante",
    "4": "Quero um(a) colaborador(a) para meu projeto",
    "5": "Quero fazer networking",
}
DIAS_LABELS = {
    "segunda": "Segunda", "terca": "Terça", "quarta": "Quarta", "quinta": "Quinta",
    "sexta": "Sexta", "sabado": "Sábado", "domingo": "Domingo",
}
PERIODO_LABELS = {"manha": "Manhã", "tarde": "Tarde", "noite": "Noite"}

_FIXOS = {"papel": PAPEL_LABELS, "disp_dias": DIAS_LABELS, "disp_periodo": PERIODO_LABELS}


# ---------- Leitura dos rótulos ----------

def _parse_choices(texto: str) -> dict:
    """Converte '1, Saúde | 2, Biologia' em {'1': 'Saúde', '2': 'Biologia'}."""
    resultado = {}
    for pedaco in (texto or "").split("|"):
        if "," not in pedaco:
            continue
        codigo, rotulo = pedaco.split(",", 1)
        codigo, rotulo = codigo.strip(), rotulo.strip()
        if codigo and rotulo:
            resultado[codigo] = rotulo
    return resultado


def _montar_a_partir_de_linhas(linhas) -> dict:
    """linhas: iterável de (nome_do_campo, tipo_do_campo, opções)."""
    rotulos = {}
    for campo, tipo, opcoes in linhas:
        if tipo in ("checkbox", "radio", "dropdown"):
            mapa = _parse_choices(opcoes)
            if mapa:
                rotulos[campo.strip()] = mapa
    return rotulos


def carregar_de_csv(caminho: str) -> dict:
    """Lê um CSV de dicionário de dados (formato do REDCap) e devolve {campo: {código: texto}}."""
    with open(caminho, newline="", encoding="utf-8-sig") as arquivo:
        leitor = csv.DictReader(arquivo)
        colunas = leitor.fieldnames or []

        def achar(prefixo):
            return next((c for c in colunas if c.strip().lower().startswith(prefixo)), None)

        col_campo = achar("variable")
        col_tipo = achar("field type")
        col_opcoes = achar("choices")
        if not (col_campo and col_tipo and col_opcoes):
            raise ValueError(
                "Formato inesperado: o CSV precisa ter as colunas 'Variable / Field Name', "
                "'Field Type' e 'Choices, Calculations, OR Slider Labels' (formato de dicionário de dados do REDCap)."
            )
        return _montar_a_partir_de_linhas(
            (l[col_campo], (l[col_tipo] or "").strip().lower(), l[col_opcoes]) for l in leitor
        )


@lru_cache(maxsize=1)
def carregar_rotulos() -> dict:
    """Dicionário {campo: {código: texto}} lido de dados/opcoes.json."""
    try:
        with open(CAMINHO_OPCOES, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError) as erro:
        print(f"Aviso: não foi possível ler {CAMINHO_OPCOES}: {erro}")
        return {}


def opcoes(campo: str) -> dict:
    """{código: texto} de um campo, na ordem do arquivo (usado nos formulários)."""
    base = dict(carregar_rotulos().get(campo, {}))
    if campo in _FIXOS and (campo in ("papel", "disp_dias", "disp_periodo") or not base):
        return dict(_FIXOS[campo])
    return base


def rotulo(campo: str, codigo: str) -> str:
    """Texto legível de uma opção; se não houver, devolve um texto genérico."""
    codigo = str(codigo)
    fixo = _FIXOS.get(campo, {}).get(codigo)
    if campo in ("disp_dias", "disp_periodo") and fixo:
        return fixo  # o dicionário traz 'terça' em minúsculo; preferimos 'Terça'
    texto = carregar_rotulos().get(campo, {}).get(codigo) or fixo
    if texto:
        return texto
    grupo = GRUPOS_INTERESSE.get(campo)
    if grupo:
        return f"{grupo} · opção {codigo}"
    return f"Opção {codigo}"


# ---------- Conversão dos campos da Pessoa ----------

def _ordem(codigo: str):
    return (0, int(codigo), "") if codigo.isdigit() else (1, 0, codigo)


def codigos(valor: str) -> list:
    """'1,3,4' -> ['1','3','4'] (ordenados; números antes de textos)."""
    itens = {c.strip() for c in (valor or "").split(",") if c.strip()}
    return sorted(itens, key=_ordem)


def chaves_interesse(pessoa) -> list:
    """Chaves como 'subareas_ti:5', na ordem dos grupos e dos códigos."""
    por_grupo = {}
    for item in codigos(pessoa.interesses):
        if ":" not in item:
            continue
        campo, cod = item.split(":", 1)
        por_grupo.setdefault(campo, []).append(cod)

    ordem_grupos = list(GRUPOS_INTERESSE) + sorted(set(por_grupo) - set(GRUPOS_INTERESSE))
    chaves = []
    for campo in ordem_grupos:
        for cod in sorted(por_grupo.get(campo, []), key=_ordem):
            chaves.append(f"{campo}:{cod}")
    return chaves


def rotulo_interesse(chave: str) -> str:
    campo, cod = chave.split(":", 1)
    return rotulo(campo, cod)


def interesses_legiveis(pessoa) -> list:
    return [rotulo_interesse(c) for c in chaves_interesse(pessoa)]


def resumo_interesses(pessoa_a, pessoa_b) -> dict:
    """
    Compara os interesses de duas pessoas.

    Devolve:
      em_comum  -- textos que as duas marcaram
      so_b      -- textos que só a pessoa B marcou (o que a A não tem)
      so_a      -- textos que só a pessoa A marcou
      total_a / total_b / total_uniao -- contagens
      percentual_comum -- em_comum / união (é a mesma conta do critério
                          "Interesses" da compatibilidade)
    """
    a = chaves_interesse(pessoa_a)
    b = chaves_interesse(pessoa_b)
    conj_a, conj_b = set(a), set(b)

    comuns = [c for c in a if c in conj_b]
    so_a = [c for c in a if c not in conj_b]
    so_b = [c for c in b if c not in conj_a]
    uniao = len(conj_a | conj_b)

    return {
        "em_comum": [rotulo_interesse(c) for c in comuns],
        "so_a": [rotulo_interesse(c) for c in so_a],
        "so_b": [rotulo_interesse(c) for c in so_b],
        "total_a": len(a),
        "total_b": len(b),
        "total_uniao": uniao,
        "percentual_comum": round(100 * len(comuns) / uniao) if uniao else 0,
    }


def resumo_do_perfil(pessoa) -> dict:
    """Todos os critérios de uma pessoa em texto legível (para o 'perfil completo')."""
    return {
        "Interesses": interesses_legiveis(pessoa),
        "Competências": [rotulo("competencias", c) for c in codigos(pessoa.competencias)],
        "Objetivo": [rotulo("objetivo", c) for c in codigos(pessoa.objetivo)],
        "Papel": [rotulo("papel", c) for c in codigos(pessoa.papel)],
        "Disponibilidade": (
            [rotulo("disp_dias", c) for c in codigos(pessoa.disp_dias)]
            + [rotulo("disp_periodo", c) for c in codigos(pessoa.disp_periodo)]
        ),
    }


# ---------- Textos dos "?" explicativos ----------

def textos_de_ajuda(pesos: dict) -> dict:
    """
    Explicações exibidas nas caixinhas de interrogação. Recebe os PESOS do
    matching.py para que o texto nunca fique desatualizado se você mudar os
    pesos lá.
    """
    def pct(chave):
        return f"{round(pesos[chave] * 100)}%"

    return {
        "compatibilidade": (
            "Nota de 0 a 100% que junta os cinco critérios ao lado, cada um com um peso: "
            f"papel {pct('papel')}, interesses {pct('interesses')}, e atividade, "
            f"competências e disponibilidade {pct('atividade')} cada. "
            "Quanto maior, mais vocês combinam para trabalhar juntos."
        ),
        "interesses": (
            "Áreas e subáreas do conhecimento (saúde, biologia, tecnologia, engenharia, "
            "gestão...) que cada pessoa marcou no cadastro. A nota sobe conforme vocês "
            "marcaram as mesmas áreas."
        ),
        "atividade": (
            "O que cada pessoa quer fazer: TCC, iniciação científica, projeto de pesquisa e "
            "outras atividades escolhidas no campo \"Objetivo\" do cadastro. "
            "A nota sobe quando vocês buscam o mesmo tipo de atividade."
        ),
        "papel": (
            "O papel que cada um quer ter: orientando(a), orientador(a), participar de um "
            "projeto, buscar um(a) colaborador(a) ou fazer networking. Aqui vale o que se "
            "COMPLETA: quem quer ser orientado combina com quem quer orientar, e quem quer "
            "colaborar combina com quem procura colaborador."
        ),
        "competencias": (
            "Habilidades e conhecimentos que cada pessoa declarou ter. "
            "A nota sobe quando vocês têm competências em comum."
        ),
        "disponibilidade": (
            "Dias da semana e períodos (manhã, tarde, noite) em que cada pessoa pode se "
            "dedicar a um projeto. A nota sobe quando os horários de vocês coincidem."
        ),
        "resumo_interesses": (
            "Compara as áreas de interesse que você marcou com as da outra pessoa: o que "
            "vocês têm em comum e o que só ela marcou. É a mesma base do critério "
            "\"Interesses\" da compatibilidade."
        ),
    }
