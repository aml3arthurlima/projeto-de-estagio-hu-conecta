"""
Diagnóstico do envio de e-mails. Uso:

    python testar_email.py seu.email@uepb.edu.br

Mostra, passo a passo, o que está certo ou errado: configuração do .env,
se o e-mail existe no banco local, e tenta mandar um e-mail de teste
exibindo o erro exato do servidor (a tela do app esconde esses erros).
A senha do SMTP nunca é impressa.
"""
import smtplib
import ssl
import sys

import email_service as es
from auth import dominio_permitido, normalizar_email
from database import SessionLocal
from models import Pessoa


def main():
    if len(sys.argv) < 2:
        print("Uso: python testar_email.py seu.email@dominio")
        return
    destino = normalizar_email(sys.argv[1])
    cfg = es._config()

    print("1) Configuração lida do .env")
    print(f"   EMAIL_MODO        = {cfg['modo']}")
    print(f"   SMTP_HOST         = {cfg['host'] or '(VAZIO)'}")
    print(f"   SMTP_PORT         = {cfg['porta']}  (SSL={cfg['ssl']}, STARTTLS={cfg['starttls']})")
    print(f"   SMTP_USER         = {cfg['usuario'] or '(VAZIO)'}")
    print(f"   SMTP_PASSWORD     = {'(preenchida)' if cfg['senha'] else '(VAZIA)'}")
    print(f"   EMAIL_REMETENTE   = {cfg['remetente'] or '(VAZIO)'}")
    if cfg["modo"] != "console" and not (cfg["host"] and cfg["remetente"]):
        print("   ✗ Falta SMTP_HOST e/ou EMAIL_REMETENTE: nenhum e-mail sai assim.")
        return

    print("\n2) Este e-mail está apto a receber o código?")
    print(f"   Domínio permitido (auth.py): {'sim' if dominio_permitido(destino) else 'NÃO'}")
    db = SessionLocal()
    pessoa = db.query(Pessoa).filter(Pessoa.email == destino).first()
    total = db.query(Pessoa).count()
    db.close()
    if pessoa:
        print(f"   Encontrado no banco local: {pessoa.nome}")
    else:
        print(f"   ✗ NÃO encontrado entre as {total} pessoas do banco local. O app só envia código "
              f"para e-mails que já fizeram o cadastro e confirmaram o código (confira se o "
              f"e-mail está escrito igual ao do cadastro).")

    if cfg["modo"] == "console":
        print("\nModo console: o e-mail só é impresso no terminal, não enviado de verdade.")
        return

    print("\n3) Tentando enviar um e-mail de teste...")
    try:
        ctx = ssl.create_default_context()
        if cfg["ssl"]:
            srv = smtplib.SMTP_SSL(cfg["host"], cfg["porta"], timeout=15, context=ctx)
        else:
            srv = smtplib.SMTP(cfg["host"], cfg["porta"], timeout=15)
        with srv:
            print("   ✓ Conectou ao servidor")
            if not cfg["ssl"] and cfg["starttls"]:
                srv.starttls(context=ctx)
                print("   ✓ STARTTLS ok")
            if cfg["usuario"]:
                srv.login(cfg["usuario"], cfg["senha"])
                print("   ✓ Login ok")
            from email.message import EmailMessage
            msg = EmailMessage()
            msg["Subject"] = "HU Conecta — teste de e-mail"
            msg["From"] = f"{cfg['nome']} <{cfg['remetente']}>"
            msg["To"] = destino
            msg.set_content("Se você recebeu isto, o envio do HU Conecta está funcionando.")
            recusados = srv.send_message(msg)
            if recusados:
                print(f"   ✗ O servidor recusou o destinatário: {recusados}")
            else:
                print("   ✓ Servidor ACEITOU a mensagem. Se não chegar, olhe spam/quarentena "
                      "(e-mail institucional costuma barrar remetentes desconhecidos).")
    except smtplib.SMTPAuthenticationError as e:
        print(f"   ✗ Usuário/senha do SMTP recusados: {e}")
    except (smtplib.SMTPConnectError, TimeoutError, ConnectionError, OSError) as e:
        print(f"   ✗ Não conseguiu conectar em {cfg['host']}:{cfg['porta']} ({e}). "
              f"Host/porta errados, ou a rede bloqueia SMTP.")
    except smtplib.SMTPException as e:
        print(f"   ✗ Erro SMTP: {e}")


if __name__ == "__main__":
    main()
