import hashlib
import unittest

import auth


class TesteHashSenha(unittest.TestCase):
    def test_formato_e_verificacao(self):
        h = auth.criar_hash_senha("minha-senha-forte")
        self.assertTrue(auth.eh_hash_formatado(h))
        self.assertTrue(h.startswith("pbkdf2_sha256$600000$"))
        self.assertNotIn("minha-senha-forte", h)
        self.assertTrue(auth.senha_confere("minha-senha-forte", h))
        self.assertFalse(auth.senha_confere("outra-senha", h))
        self.assertFalse(auth.senha_confere("", h))

    def test_mesma_senha_gera_hashes_diferentes(self):
        self.assertNotEqual(auth.criar_hash_senha("abc12345"), auth.criar_hash_senha("abc12345"))

    def test_hash_legado_continua_funcionando_e_pede_atualizacao(self):
        salt = "abcdef"
        legado = hashlib.pbkdf2_hmac("sha256", b"senha123", salt.encode(), 100_000).hex()
        self.assertTrue(auth.senha_confere("senha123", legado, salt))
        self.assertFalse(auth.senha_confere("errada", legado, salt))
        self.assertFalse(auth.senha_confere("senha123", legado, ""))  # sem salt não confere
        self.assertTrue(auth.precisa_atualizar_hash(legado))
        self.assertFalse(auth.precisa_atualizar_hash(auth.criar_hash_senha("x" * 8)))

    def test_entradas_invalidas_nao_quebram(self):
        self.assertFalse(auth.senha_confere("x", "pbkdf2_sha256$abc$s$h"))
        self.assertFalse(auth.senha_confere("x", ""))
        self.assertFalse(auth.eh_hash_formatado(None))
        self.assertFalse(auth.eh_hash_formatado("123456"))
        self.assertFalse(auth.eh_hash_formatado("pbkdf2_sha256$600000$salt"))

    def test_validar_nova_senha(self):
        self.assertIsNotNone(auth.validar_nova_senha("curta", "curta"))
        self.assertIsNotNone(auth.validar_nova_senha("senhaboa123", "diferente"))
        self.assertIsNone(auth.validar_nova_senha("senhaboa123", "senhaboa123"))


class TesteCodigoRecuperacao(unittest.TestCase):
    def test_codigo_tem_6_digitos_e_confere(self):
        codigo = auth.gerar_codigo_recuperacao()
        self.assertRegex(codigo, r"^\d{6}$")
        salt = auth.gerar_salt()
        h = auth.hash_codigo(codigo, salt)
        self.assertNotIn(codigo, h)
        self.assertTrue(auth.codigo_confere(codigo, salt, h))
        self.assertTrue(auth.codigo_confere(f" {codigo} ", salt, h))  # tolera espaços
        outro = "000000" if codigo != "000000" else "111111"
        self.assertFalse(auth.codigo_confere(outro, salt, h))


class TesteEmailEDominio(unittest.TestCase):
    def test_normalizar(self):
        self.assertEqual(auth.normalizar_email("  Joao@UEPB.edu.br "), "joao@uepb.edu.br")

    def test_dominios(self):
        self.assertTrue(auth.dominio_permitido("a@aluno.uepb.edu.br"))
        self.assertTrue(auth.dominio_permitido("a@huac.ebserh.gov.br"))
        self.assertFalse(auth.dominio_permitido("a@gmail.com"))
        self.assertFalse(auth.dominio_permitido("a@falsouepb.edu.br"))
        self.assertFalse(auth.dominio_permitido("sem-arroba"))


if __name__ == "__main__":
    unittest.main()
