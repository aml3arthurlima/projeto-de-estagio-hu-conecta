import io
import os
import unittest
from contextlib import redirect_stdout
from unittest import mock

import email_service as es


class TesteEnvio(unittest.TestCase):
    def test_modo_console_imprime_e_retorna_true(self):
        with mock.patch.dict(os.environ, {"EMAIL_MODO": "console"}):
            buf = io.StringIO()
            with redirect_stdout(buf):
                ok = es.enviar_email("a@uepb.edu.br", "Assunto\ncom quebra", "corpo 123456")
        self.assertTrue(ok)
        self.assertIn("corpo 123456", buf.getvalue())
        self.assertIn("Assunto com quebra", buf.getvalue())  # quebra de linha removida

    def test_sem_smtp_configurado_falha_sem_excecao(self):
        env = {"EMAIL_MODO": "smtp", "SMTP_HOST": "", "EMAIL_REMETENTE": "", "SMTP_USER": ""}
        with mock.patch.dict(os.environ, env):
            with redirect_stdout(io.StringIO()):
                self.assertFalse(es.enviar_email("a@uepb.edu.br", "x", "y"))
            self.assertFalse(es.email_configurado())

    def test_destino_invalido(self):
        self.assertFalse(es.enviar_email("", "x", "y"))
        self.assertFalse(es.enviar_email("sem-arroba", "x", "y"))

    def test_smtp_usa_starttls_e_login(self):
        env = {"EMAIL_MODO": "smtp", "SMTP_HOST": "smtp.teste", "SMTP_PORT": "587",
               "SMTP_USER": "u", "SMTP_PASSWORD": "p", "EMAIL_REMETENTE": "hu@teste.gov.br"}
        with mock.patch.dict(os.environ, env), mock.patch("email_service.smtplib.SMTP") as smtp:
            servidor = smtp.return_value  # smtplib devolve o próprio objeto no 'with'
            ok = es.enviar_email("a@uepb.edu.br", "Oi", "texto", "<p>html</p>")
        self.assertTrue(ok)
        servidor.starttls.assert_called_once()
        servidor.login.assert_called_once_with("u", "p")
        servidor.send_message.assert_called_once()


class TesteTemplates(unittest.TestCase):
    def test_codigo(self):
        assunto, texto, html = es.montar_email_codigo("Ana", "123456", 15)
        self.assertIn("123456", texto)
        self.assertIn("123456", html)

    def test_html_escapa_dados_de_cadastro(self):
        quem = {"nome": "<script>alert(1)</script>", "vinculo": "Docente", "curso": "", "instituicao": "UEPB"}
        _, _, html = es.montar_email_novo_interesse("Beto", quem, ["<b>IA</b>"], True)
        self.assertNotIn("<script>", html)
        self.assertNotIn("<b>IA</b>", html)
        self.assertIn("&lt;script&gt;", html)

    def test_interesse_nao_vaza_contato_e_respeita_anonimato(self):
        quem = {"nome": "Carla", "vinculo": "Docente", "curso": "Medicina", "instituicao": "UFCG",
                "email": "carla@ufcg.edu.br", "telefone": "8399999"}
        a1, t1, h1 = es.montar_email_novo_interesse("Beto", quem, [], True)
        self.assertIn("Carla", a1)
        self.assertNotIn("carla@ufcg.edu.br", t1 + h1)
        self.assertNotIn("8399999", t1 + h1)
        a2, t2, h2 = es.montar_email_novo_interesse("Beto", quem, [], False)
        self.assertNotIn("Carla", a2 + t2 + h2)
        self.assertIn("Medicina", t2)

    def test_conexao_inclui_contato_e_interesses(self):
        outro = {"nome": "Carla", "vinculo": "Docente", "curso": "Medicina", "instituicao": "UFCG",
                 "email": "carla@ufcg.edu.br", "telefone": "8399999"}
        assunto, texto, html = es.montar_email_conexao("Beto", outro, ["IA", "Saúde digital"])
        self.assertIn("Carla", assunto)
        for trecho in ("carla@ufcg.edu.br", "8399999", "IA", "Saúde digital"):
            self.assertIn(trecho, texto)
            self.assertIn(trecho, html)


if __name__ == "__main__":
    unittest.main()
