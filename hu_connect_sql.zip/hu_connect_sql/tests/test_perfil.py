import unittest

import perfil


def dados_ok(**extra):
    base = {
        "nome": "Ana Souza", "email": "ana@aluno.uepb.edu.br", "telefone": "(83) 99999-1234",
        "lattes": "http://lattes.cnpq.br/123", "vinculo": "1", "curso": "4",
        "instituicoes": ["3"], "outras_instituicoes": "", "bio": "Oi",
        "objetivo": ["1"], "papel": ["1"], "competencias": ["1", "2"],
        "interesses": ["interesses:3", "subareas_ti:1"], "disp_dias": ["segunda"], "disp_periodo": ["tarde"],
    }
    base.update(extra)
    return base


class TesteValidacao(unittest.TestCase):
    def test_dados_corretos(self):
        self.assertEqual(perfil.validar_dados(dados_ok()), [])

    def test_obrigatorios(self):
        erros = perfil.validar_dados(perfil.dados_vazios())
        self.assertGreaterEqual(len(erros), 8)

    def test_email_fora_do_dominio(self):
        self.assertTrue(perfil.validar_dados(dados_ok(email="ana@gmail.com")))
        self.assertEqual(perfil.validar_dados(dados_ok(email="ana@gmail.com"), validar_dominio_do_email=False), [])

    def test_telefone(self):
        self.assertTrue(perfil.validar_dados(dados_ok(telefone="12345")))
        self.assertEqual(perfil.validar_dados(dados_ok(telefone="8399999123")), [])  # 10 dígitos

    def test_lattes_precisa_ser_http(self):
        self.assertTrue(perfil.validar_dados(dados_ok(lattes="javascript:alert(1)")))
        self.assertTrue(perfil.validar_dados(dados_ok(lattes="http://a.com/ b")))
        self.assertEqual(perfil.validar_dados(dados_ok(lattes="https://lattes.cnpq.br/1")), [])

    def test_codigos_inventados_sao_recusados(self):
        self.assertTrue(perfil.validar_dados(dados_ok(vinculo="77")))
        self.assertTrue(perfil.validar_dados(dados_ok(papel=["9"])))
        self.assertTrue(perfil.validar_dados(dados_ok(interesses=["subareas_ti:999"])))
        self.assertTrue(perfil.validar_dados(dados_ok(disp_dias=["domingao"])))
        self.assertTrue(perfil.validar_dados(dados_ok(instituicoes=["55"])))

    def test_outra_instituicao_exige_nome(self):
        self.assertTrue(perfil.validar_dados(dados_ok(instituicoes=["99"], outras_instituicoes="")))
        self.assertEqual(perfil.validar_dados(dados_ok(instituicoes=["99"], outras_instituicoes="Univ. X")), [])


class TesteConversao(unittest.TestCase):
    def test_campos_da_pessoa(self):
        c = perfil.para_campos_pessoa(dados_ok(instituicoes=["3", "99"], outras_instituicoes="Univ. X",
                                               email="  ANA@aluno.uepb.edu.br "))
        self.assertEqual(c["email"], "ana@aluno.uepb.edu.br")
        self.assertEqual(c["telefone"], "83999991234")
        self.assertEqual(c["vinculo"], "Aluno de graduação")
        self.assertEqual(c["curso"], "Análise e Desenvolvimento de Sistemas")
        self.assertEqual(c["instituicao"], "UEPB, Univ. X")
        self.assertEqual(c["interesses"], "interesses:3,subareas_ti:1")  # formato que o matching espera
        self.assertEqual(c["competencias"], "1,2")

    def test_alimenta_o_motor_de_compatibilidade(self):
        from types import SimpleNamespace as P
        from matching import calcular_compatibilidade
        a = P(**perfil.para_campos_pessoa(dados_ok(papel=["1"])))
        b = P(**perfil.para_campos_pessoa(dados_ok(email="b@uepb.edu.br", papel=["2"])))
        r = calcular_compatibilidade(a, b)
        self.assertGreater(r.score_total, 50)
        self.assertEqual(r.score_papel, 100)


if __name__ == "__main__":
    unittest.main()
