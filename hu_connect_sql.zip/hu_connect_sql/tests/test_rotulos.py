import csv
import os
import tempfile
import unittest
from types import SimpleNamespace

import rotulos


def pessoa(interesses="", **kw):
    base = dict(interesses=interesses, competencias="", objetivo="", papel="", disp_dias="", disp_periodo="")
    base.update(kw)
    return SimpleNamespace(**base)


class TesteDicionario(unittest.TestCase):
    def test_parse_choices(self):
        self.assertEqual(rotulos._parse_choices("1, Saúde | 2, Biologia, molecular |  "),
                         {"1": "Saúde", "2": "Biologia, molecular"})

    def test_carregar_csv_do_redcap(self):
        with tempfile.TemporaryDirectory() as d:
            caminho = os.path.join(d, "dic.csv")
            with open(caminho, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                w.writerow(["Variable / Field Name", "Form Name", "Field Type", "Field Label",
                            "Choices, Calculations, OR Slider Labels"])
                w.writerow(["subareas_ti", "cadastro", "checkbox", "TI", "1, IA | 5, Saúde digital"])
                w.writerow(["nome", "cadastro", "text", "Nome", ""])
            r = rotulos.carregar_de_csv(caminho)
        self.assertEqual(r, {"subareas_ti": {"1": "IA", "5": "Saúde digital"}})


class TesteResumo(unittest.TestCase):
    def setUp(self):
        self._orig = rotulos.carregar_rotulos
        rotulos.carregar_rotulos = lambda: {
            "subareas_ti": {"1": "IA", "5": "Saúde digital"},
            "interesses": {"3": "Tecnologia"},
        }

    def tearDown(self):
        rotulos.carregar_rotulos = self._orig

    def test_rotulo_com_e_sem_dicionario(self):
        self.assertEqual(rotulos.rotulo("subareas_ti", "5"), "Saúde digital")
        self.assertEqual(rotulos.rotulo("subareas_ti", "9"), "Tecnologia da informação · opção 9")
        self.assertEqual(rotulos.rotulo("papel", "1"), "Quero ser orientando(a)")
        self.assertEqual(rotulos.rotulo("disp_dias", "terca"), "Terça")
        self.assertEqual(rotulos.rotulo("competencias", "7"), "Opção 7")

    def test_dicionario_real_do_projeto(self):
        rotulos.carregar_rotulos = self._orig
        rotulos.carregar_rotulos.cache_clear()
        self.assertEqual(rotulos.rotulo("competencias", "1"), "Python")
        self.assertEqual(rotulos.rotulo("subareas_ti", "1"), "Desenvolvimento de Software")
        self.assertEqual(rotulos.rotulo("disp_dias", "terca"), "Terça")

    def test_resumo_em_comum_e_exclusivos(self):
        a = pessoa("interesses:3,subareas_ti:1")
        b = pessoa("interesses:3,subareas_ti:5")
        r = rotulos.resumo_interesses(a, b)
        self.assertEqual(r["em_comum"], ["Tecnologia"])
        self.assertEqual(r["so_a"], ["IA"])
        self.assertEqual(r["so_b"], ["Saúde digital"])
        self.assertEqual(r["total_uniao"], 3)
        self.assertEqual(r["percentual_comum"], 33)

    def test_resumo_sem_interesses(self):
        r = rotulos.resumo_interesses(pessoa(""), pessoa(""))
        self.assertEqual((r["em_comum"], r["total_uniao"], r["percentual_comum"]), ([], 0, 0))

    def test_ordem_numerica(self):
        p = pessoa("subareas_ti:10,subareas_ti:2,interesses:1")
        self.assertEqual(rotulos.chaves_interesse(p), ["interesses:1", "subareas_ti:2", "subareas_ti:10"])

    def test_perfil_completo(self):
        p = pessoa("interesses:3", papel="1,2", disp_dias="segunda,sexta", disp_periodo="manha")
        perfil = rotulos.resumo_do_perfil(p)
        self.assertEqual(perfil["Interesses"], ["Tecnologia"])
        self.assertEqual(perfil["Papel"], ["Quero ser orientando(a)", "Quero ser orientador(a)"])
        self.assertEqual(perfil["Disponibilidade"], ["Segunda", "Sexta", "Manhã"])

    def test_textos_de_ajuda_usam_os_pesos(self):
        pesos = {"interesses": 0.25, "atividade": 0.15, "papel": 0.30, "competencias": 0.15, "disponibilidade": 0.15}
        ajuda = rotulos.textos_de_ajuda(pesos)
        self.assertIn("30%", ajuda["compatibilidade"])
        self.assertIn("25%", ajuda["compatibilidade"])
        for chave in ("interesses", "atividade", "papel", "competencias", "disponibilidade", "resumo_interesses"):
            self.assertTrue(ajuda[chave])


if __name__ == "__main__":
    unittest.main()
