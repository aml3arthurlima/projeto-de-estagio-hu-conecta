"""
Testes dos serviços que usam banco de dados (cadastro, avisos por e-mail e
recuperação de senha). Usam um SQLite temporário -- NÃO mexem no seu banco de
verdade -- e nenhum e-mail é enviado de verdade (tudo é simulado com mock).

Rodar (na pasta do projeto, com as dependências instaladas):
    python -m unittest tests.test_servicos -v
"""
import os
import re
import tempfile
import unittest
from datetime import datetime, timedelta
from unittest import mock

# Precisa vir ANTES de importar `database`: aponta para um banco temporário.
_pasta = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(_pasta, "teste.db").replace("\\", "/")

try:
    import cadastro
    import database
    import notificacoes
    import recuperacao
    from auth import criar_hash_senha, eh_hash_formatado, senha_confere
    from models import Base, CadastroPendente, CodigoRecuperacao, Credencial, Interacao, Match, Notificacao, Pessoa
    TEM_DEPS = True
except ImportError:  # sem sqlalchemy/pandas/dotenv instalados
    TEM_DEPS = False


@unittest.skipUnless(TEM_DEPS, "instale as dependências do requirements.txt para rodar estes testes")
class BaseComBanco(unittest.TestCase):
    def setUp(self):
        Base.metadata.drop_all(database.engine)
        Base.metadata.create_all(database.engine)
        self.db = database.SessionLocal()
        self.addCleanup(self.db.close)

        # Nenhum e-mail real: tudo cai nesta lista.
        self.enviados = []

        def falso_enviar(destino, assunto, texto, html=None):
            self.enviados.append((destino, assunto, texto))
            return True

        p = mock.patch("email_service.enviar_email", side_effect=falso_enviar)
        p.start()
        self.addCleanup(p.stop)

        self.ana = self.nova_pessoa(1, "Ana", "ana@uepb.edu.br", telefone="8399999", interesses="interesses:1,subareas_ti:2")
        self.bia = self.nova_pessoa(2, "Bia", "bia@uepb.edu.br", interesses="interesses:1")

    def nova_pessoa(self, id_, nome, email, **kw):
        p = Pessoa(id=id_, nome=nome, email=email, **kw)
        self.db.add(p)
        self.db.commit()
        return p


class TesteNotificacoes(BaseComBanco):
    def test_interesse_unilateral_avisa_so_quem_recebeu_e_nao_duplica(self):
        r = notificacoes.registrar_interacao(self.db, 1, 2, "like")
        self.assertTrue(r.registrada)
        self.assertFalse(r.conexao)
        self.assertEqual([e[0] for e in self.enviados], ["bia@uepb.edu.br"])
        notificacoes.registrar_interacao(self.db, 1, 2, "like")  # de novo: não repete o aviso
        self.assertEqual(len(self.enviados), 1)

    def test_aviso_de_interesse_nao_vaza_contato(self):
        notificacoes.registrar_interacao(self.db, 1, 2, "like")
        texto = self.enviados[0][2]
        self.assertIn("Ana", texto)
        self.assertNotIn("ana@uepb.edu.br", texto)
        self.assertNotIn("8399999", texto)

    def test_conexao_avisa_os_dois_com_contato(self):
        notificacoes.registrar_interacao(self.db, 1, 2, "like")
        self.enviados.clear()
        r = notificacoes.registrar_interacao(self.db, 2, 1, "like")
        self.assertTrue(r.conexao)
        self.assertEqual(sorted(e[0] for e in self.enviados), ["ana@uepb.edu.br", "bia@uepb.edu.br"])
        para_bia = next(e[2] for e in self.enviados if e[0] == "bia@uepb.edu.br")
        self.assertIn("ana@uepb.edu.br", para_bia)
        self.assertIn("8399999", para_bia)
        # repetir não reenvia
        notificacoes.registrar_interacao(self.db, 2, 1, "like")
        self.assertEqual(len(self.enviados), 2)

    def test_nao_avisa_interesse_se_a_outra_pessoa_ja_decidiu(self):
        notificacoes.registrar_interacao(self.db, 2, 1, "skip")  # Bia ignorou Ana
        notificacoes.registrar_interacao(self.db, 1, 2, "like")
        self.assertEqual(self.enviados, [])

    def test_skip_nao_envia_nada_e_autointeracao_e_ignorada(self):
        notificacoes.registrar_interacao(self.db, 1, 2, "skip")
        self.assertEqual(self.enviados, [])
        self.assertFalse(notificacoes.registrar_interacao(self.db, 1, 1, "like").registrada)
        with self.assertRaises(ValueError):
            notificacoes.registrar_interacao(self.db, 1, 99, "like")

    def test_email_que_falha_nao_impede_o_like_nem_marca_como_enviado(self):
        with mock.patch("email_service.enviar_email", return_value=False):
            r = notificacoes.registrar_interacao(self.db, 1, 2, "like")
        self.assertTrue(r.registrada)
        self.assertEqual(self.db.query(Notificacao).count(), 0)  # tentará de novo numa próxima vez

    def test_ids_que_demonstraram_interesse(self):
        notificacoes.registrar_interacao(self.db, 1, 2, "like")
        self.assertEqual(notificacoes.ids_que_demonstraram_interesse(self.db, 2), {1})
        self.assertEqual(notificacoes.ids_que_demonstraram_interesse(self.db, 1), set())
        # Depois que a Bia decide (aqui, ignora a Ana), a Ana deixa de contar como "esperando resposta".
        notificacoes.registrar_interacao(self.db, 2, 1, "skip")
        self.assertEqual(notificacoes.ids_que_demonstraram_interesse(self.db, 2), set())


class TesteRecuperacao(BaseComBanco):
    def codigo_do_ultimo_email(self):
        return re.search(r"\b(\d{6})\b", self.enviados[-1][2]).group(1)

    def test_email_desconhecido_ou_de_dominio_nao_aceito_nao_envia_nada(self):
        recuperacao.solicitar_codigo(self.db, "ninguem@uepb.edu.br")
        recuperacao.solicitar_codigo(self.db, "ana@gmail.com")
        self.assertEqual(self.enviados, [])
        self.assertEqual(self.db.query(CodigoRecuperacao).count(), 0)

    def test_fluxo_completo(self):
        recuperacao.solicitar_codigo(self.db, "  ANA@uepb.edu.br ")
        self.assertEqual(len(self.enviados), 1)
        self.assertEqual(self.enviados[0][0], "ana@uepb.edu.br")
        codigo = self.codigo_do_ultimo_email()
        # o código nunca fica guardado em texto puro
        self.assertNotEqual(self.db.query(CodigoRecuperacao).one().codigo_hash, codigo)

        ok, _ = recuperacao.redefinir_senha(self.db, "ana@uepb.edu.br", "000000" if codigo != "000000" else "111111",
                                            "senhaNova123", "senhaNova123")
        self.assertFalse(ok)
        self.assertEqual(self.db.query(CodigoRecuperacao).one().tentativas, 1)

        ok, mensagem = recuperacao.redefinir_senha(self.db, "ana@uepb.edu.br", codigo, "senhaNova123", "senhaNova123")
        self.assertTrue(ok, mensagem)
        cred = self.db.query(Credencial).filter_by(pessoa_id=1).one()
        self.assertTrue(eh_hash_formatado(cred.senha_hash))
        self.assertTrue(senha_confere("senhaNova123", cred.senha_hash, cred.salt))
        self.assertEqual(self.db.query(CodigoRecuperacao).count(), 0)
        self.assertIn("alterada", self.enviados[-1][1])  # aviso de segurança

        # o mesmo código não funciona duas vezes
        ok, _ = recuperacao.redefinir_senha(self.db, "ana@uepb.edu.br", codigo, "outraSenha123", "outraSenha123")
        self.assertFalse(ok)

    def test_troca_senha_existente_e_encerra_sessoes(self):
        from models import Sessao
        self.db.add(Credencial(pessoa_id=1, email="ana@uepb.edu.br", senha_hash=criar_hash_senha("antiga1234"), salt=""))
        self.db.add(Sessao(token="abc", pessoa_id=1))
        self.db.commit()
        recuperacao.solicitar_codigo(self.db, "ana@uepb.edu.br")
        ok, _ = recuperacao.redefinir_senha(self.db, "ana@uepb.edu.br", self.codigo_do_ultimo_email(), "novaSenha123", "novaSenha123")
        self.assertTrue(ok)
        cred = self.db.query(Credencial).filter_by(pessoa_id=1).one()
        self.assertFalse(senha_confere("antiga1234", cred.senha_hash, cred.salt))
        self.assertTrue(senha_confere("novaSenha123", cred.senha_hash, cred.salt))
        self.assertEqual(self.db.query(Sessao).count(), 0)

    def test_limite_de_pedidos_seguidos(self):
        recuperacao.solicitar_codigo(self.db, "ana@uepb.edu.br")
        recuperacao.solicitar_codigo(self.db, "ana@uepb.edu.br")
        self.assertEqual(len(self.enviados), 1)

    def test_codigo_expirado(self):
        recuperacao.solicitar_codigo(self.db, "ana@uepb.edu.br")
        codigo = self.codigo_do_ultimo_email()
        reg = self.db.query(CodigoRecuperacao).one()
        reg.expira_em = datetime.utcnow() - timedelta(seconds=1)
        self.db.commit()
        ok, _ = recuperacao.redefinir_senha(self.db, "ana@uepb.edu.br", codigo, "senhaNova123", "senhaNova123")
        self.assertFalse(ok)
        self.assertEqual(self.db.query(Credencial).count(), 0)

    def test_bloqueia_apos_muitas_tentativas_erradas(self):
        recuperacao.solicitar_codigo(self.db, "ana@uepb.edu.br")
        certo = self.codigo_do_ultimo_email()
        errado = "000000" if certo != "000000" else "111111"
        for _ in range(5):
            self.assertFalse(recuperacao.redefinir_senha(self.db, "ana@uepb.edu.br", errado, "senhaNova123", "senhaNova123")[0])
        # agora nem o código certo vale mais
        self.assertFalse(recuperacao.redefinir_senha(self.db, "ana@uepb.edu.br", certo, "senhaNova123", "senhaNova123")[0])

    def test_senha_fraca_ou_diferente_nao_gasta_tentativa(self):
        recuperacao.solicitar_codigo(self.db, "ana@uepb.edu.br")
        codigo = self.codigo_do_ultimo_email()
        self.assertFalse(recuperacao.redefinir_senha(self.db, "ana@uepb.edu.br", codigo, "curta", "curta")[0])
        self.assertFalse(recuperacao.redefinir_senha(self.db, "ana@uepb.edu.br", codigo, "senhaNova123", "diferente123")[0])
        self.assertEqual(self.db.query(CodigoRecuperacao).one().tentativas, 0)

    def test_quem_nunca_teve_senha_tambem_consegue_definir(self):
        # substitui a antiga aba "Primeiro acesso", agora com prova de posse do e-mail
        self.assertEqual(self.db.query(Credencial).count(), 0)
        recuperacao.solicitar_codigo(self.db, "bia@uepb.edu.br")
        ok, _ = recuperacao.redefinir_senha(self.db, "bia@uepb.edu.br", self.codigo_do_ultimo_email(), "senhaNova123", "senhaNova123")
        self.assertTrue(ok)
        self.assertEqual(self.db.query(Credencial).filter_by(pessoa_id=2).count(), 1)


def dados_cadastro(**extra):
    base = {
        "nome": "Eva Nova", "email": "eva@aluno.uepb.edu.br", "telefone": "83999991234",
        "lattes": "http://lattes.cnpq.br/1", "vinculo": "1", "curso": "4", "instituicoes": ["3"],
        "outras_instituicoes": "", "bio": "", "objetivo": ["1"], "papel": ["2"], "competencias": ["1"],
        "interesses": ["interesses:1"], "disp_dias": ["segunda"], "disp_periodo": ["tarde"],
    }
    base.update(extra)
    return base


class TesteCadastro(BaseComBanco):
    def codigo_do_ultimo_email(self):
        return re.search(r"\b(\d{6})\b", self.enviados[-1][2]).group(1)

    def test_fluxo_completo_cria_pessoa_senha_em_hash_e_matches(self):
        ok, erros = cadastro.iniciar_cadastro(self.db, dados_cadastro(), "senhaForte123", "senhaForte123")
        self.assertTrue(ok, erros)
        self.assertEqual(self.enviados[-1][0], "eva@aluno.uepb.edu.br")
        self.assertEqual(self.db.query(Pessoa).filter_by(email="eva@aluno.uepb.edu.br").count(), 0)  # ainda não existe

        ok, msg, pid = cadastro.confirmar_cadastro(self.db, "eva@aluno.uepb.edu.br", self.codigo_do_ultimo_email())
        self.assertTrue(ok, msg)
        pessoa = self.db.get(Pessoa, pid)
        self.assertEqual(pessoa.vinculo, "Aluno de graduação")
        self.assertEqual(pessoa.papel, "2")
        cred = self.db.query(Credencial).filter_by(pessoa_id=pid).one()
        self.assertTrue(eh_hash_formatado(cred.senha_hash))
        self.assertTrue(senha_confere("senhaForte123", cred.senha_hash, cred.salt))
        self.assertEqual(self.db.query(CadastroPendente).count(), 0)
        self.assertEqual(self.db.query(Match).count(), 2)  # Eva x Ana e Eva x Bia

    def test_dados_ou_senha_invalidos(self):
        ok, erros = cadastro.iniciar_cadastro(self.db, dados_cadastro(telefone="1"), "senhaForte123", "outra")
        self.assertFalse(ok)
        self.assertGreaterEqual(len(erros), 2)
        self.assertEqual(self.enviados, [])

    def test_email_ja_cadastrado(self):
        ok, erros = cadastro.iniciar_cadastro(self.db, dados_cadastro(email="ana@uepb.edu.br"), "senhaForte123", "senhaForte123")
        self.assertFalse(ok)
        self.assertIn("já tem cadastro", erros[0])

    def test_codigo_errado_nao_cria_conta_e_bloqueia(self):
        cadastro.iniciar_cadastro(self.db, dados_cadastro(), "senhaForte123", "senhaForte123")
        certo = self.codigo_do_ultimo_email()
        errado = "000000" if certo != "000000" else "111111"
        for _ in range(5):
            self.assertFalse(cadastro.confirmar_cadastro(self.db, "eva@aluno.uepb.edu.br", errado)[0])
        self.assertFalse(cadastro.confirmar_cadastro(self.db, "eva@aluno.uepb.edu.br", certo)[0])
        self.assertEqual(self.db.query(Pessoa).filter_by(email="eva@aluno.uepb.edu.br").count(), 0)

    def test_pedidos_seguidos_e_falha_de_envio(self):
        self.assertTrue(cadastro.iniciar_cadastro(self.db, dados_cadastro(), "senhaForte123", "senhaForte123")[0])
        self.assertFalse(cadastro.iniciar_cadastro(self.db, dados_cadastro(), "senhaForte123", "senhaForte123")[0])
        with mock.patch("email_service.enviar_email", return_value=False):
            ok, erros = cadastro.iniciar_cadastro(self.db, dados_cadastro(email="fim@aluno.uepb.edu.br"), "senhaForte123", "senhaForte123")
        self.assertFalse(ok)
        self.assertEqual(self.db.query(CadastroPendente).filter_by(email="fim@aluno.uepb.edu.br").count(), 0)

    def test_editar_perfil_recalcula_matches_e_nao_troca_email(self):
        dados = dados_cadastro(email="ana@uepb.edu.br", nome="Ana Renomeada", papel=["1"])
        ok, erros = cadastro.atualizar_perfil(self.db, 1, {**dados, "email": "outro@uepb.edu.br"})
        self.assertTrue(ok, erros)
        ana = self.db.get(Pessoa, 1)
        self.assertEqual(ana.nome, "Ana Renomeada")
        self.assertEqual(ana.email, "ana@uepb.edu.br")  # e-mail não muda
        self.assertEqual(cadastro.dados_do_formulario(ana)["papel"], ["1"])
        self.assertEqual(self.db.query(Match).count(), 1)  # Ana x Bia, sem duplicar

    def test_excluir_conta_apaga_tudo_da_pessoa(self):
        self.db.add(Credencial(pessoa_id=1, email="ana@uepb.edu.br", senha_hash=criar_hash_senha("minhaSenha12"), salt=""))
        self.db.commit()
        notificacoes.registrar_interacao(self.db, 1, 2, "like")
        self.assertFalse(cadastro.excluir_conta(self.db, 1, "senhaErrada")[0])
        self.assertTrue(cadastro.excluir_conta(self.db, 1, "minhaSenha12")[0])
        self.assertIsNone(self.db.get(Pessoa, 1))
        self.assertEqual(self.db.query(Credencial).count(), 0)
        self.assertEqual(self.db.query(Interacao).count(), 0)
        self.assertEqual(self.db.query(Notificacao).count(), 0)
        self.assertIsNotNone(self.db.get(Pessoa, 2))  # a outra pessoa continua


if __name__ == "__main__":
    unittest.main()
